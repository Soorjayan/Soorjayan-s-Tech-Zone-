# Category & Brand Management

This module extends the existing Soorjayan's Tech Zone backend with separate Admin-managed Category and Brand entities.

## Design

The existing `Product` model still stores `category` and `brand` as strings. This preserves compatibility with existing products such as Dell XPS 15, Logitech G502 Mouse, and ASUS ROG Strix G16.

Category/Brand records are managed separately and calculate `productCount` dynamically from Product records.

Renaming a Category or Brand automatically updates the corresponding Product string values.

Deletion is blocked while products still use the entity; deactivation is available instead.

## Category API

Public reads:
- `GET /api/categories`
- `GET /api/categories/:id`

Admin only:
- `GET /api/categories/stats`
- `POST /api/categories`
- `PUT /api/categories/:id`
- `PATCH /api/categories/:id/status`
- `DELETE /api/categories/:id`

Query parameters for list:
- `search`
- `status=active|inactive`
- `page`
- `limit`
- `sort=newest|oldest|name_asc|name_desc`

Create example:
```json
{
  "name": "Laptops",
  "description": "Laptop computers and notebooks",
  "image": "https://example.com/laptops.jpg"
}
```

## Brand API

Public reads:
- `GET /api/brands`
- `GET /api/brands/:id`

Admin only:
- `GET /api/brands/stats`
- `POST /api/brands`
- `PUT /api/brands/:id`
- `PATCH /api/brands/:id/status`
- `DELETE /api/brands/:id`

Query parameters for list:
- `search`
- `status=active|inactive`
- `page`
- `limit`
- `sort=newest|oldest|name_asc|name_desc`

Create example:
```json
{
  "name": "Dell",
  "description": "Dell laptops and computing products",
  "logo": "https://example.com/dell-logo.png"
}
```

## Important testing order

1. Create `Laptops` category.
2. Create `Dell` brand.
3. Get category by ID and verify Dell XPS 15 appears with `productCount: 1`.
4. Get brand by ID and verify Dell XPS 15 appears with `productCount: 1`.
5. Test category/brand search, status filtering and statistics.
6. Test rename behavior only on a test entity or after understanding that product string values are updated automatically.
7. Test deletion protection on Laptops and Dell; both should be blocked because existing products use them.

## Authentication

Use Admin Bearer JWT for all mutation and statistics endpoints.

Do not include `.env` or secrets in source control.
