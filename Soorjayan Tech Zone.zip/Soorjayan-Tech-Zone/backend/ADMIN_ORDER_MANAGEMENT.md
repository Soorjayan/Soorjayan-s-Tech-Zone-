# Admin Order Management – Soorjayan's Tech Zone

This update extends the existing Order API without changing the current authentication or MongoDB setup.

## Added / improved functionality

### 1. View all orders
`GET /api/orders`

Admin and staff can use:

- `search` – customer name/email, phone, or shipping address
- `status` – order status filter
- `paymentMethod` – `COD` or `BANK_TRANSFER`
- `page` – page number
- `limit` – records per page (maximum 100)
- `sort` – `newest`, `oldest`, `highest`, `lowest`

Example:
`GET http://localhost:5000/api/orders?status=PLACED&page=1&limit=10&sort=newest`

### 2. View one order
`GET /api/orders/:id`

Allowed roles: admin, staff, delivery.

### 3. Order statistics
`GET /api/orders/stats`

Admin only.

Returns:
- total orders
- active orders
- cancelled orders
- total revenue from non-cancelled orders
- average order value from non-cancelled orders
- order status breakdown
- payment-method breakdown

### 4. Update order status
`PUT /api/orders/:id/status`

Body:
```json
{
  "orderStatus": "CONFIRMED"
}
```

Supported statuses:
- `PLACED`
- `CONFIRMED`
- `PROCESSING`
- `SHIPPED`
- `OUT_FOR_DELIVERY`
- `DELIVERED`
- `CANCELLED`

### 5. Cancel an order
`PUT /api/orders/:id/cancel`

Customer: can cancel only their own `PLACED` or `CONFIRMED` order.

Admin: can cancel any `PLACED` or `CONFIRMED` order.

When an order is cancelled, the ordered quantities are returned to product stock. The cancellation is protected against repeated cancellation.

## Authentication

Use the existing JWT authentication:

```text
Authorization: Bearer YOUR_JWT_TOKEN
```

Do not place `.env` or secrets in GitHub or in the shared ZIP.

## Recommended Postman testing order

1. Login as admin.
2. Copy the JWT token.
3. Test `GET /api/orders`.
4. Copy an order `_id`.
5. Test `GET /api/orders/:id`.
6. Test `GET /api/orders/stats`.
7. Test `PUT /api/orders/:id/status` with `CONFIRMED`.
8. Test `PUT /api/orders/:id/status` with `PROCESSING`.
9. For a test order in `PLACED` or `CONFIRMED`, test cancellation and verify that product stock is restored.

## Important route detail

The `/stats` route is declared before `/:id`. This prevents Express from interpreting `stats` as an order ID.
