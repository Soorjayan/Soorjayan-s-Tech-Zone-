const jwt=require('jsonwebtoken');
const bcrypt=require('bcryptjs');
const signToken=(user)=>jwt.sign({id:user._id.toString(),role:user.role},process.env.JWT_SECRET,{expiresIn:process.env.JWT_EXPIRES_IN||'7d'});
const hashPassword=(p)=>bcrypt.hash(p,10);
const comparePassword=(p,h)=>bcrypt.compare(p,h);
module.exports={signToken,hashPassword,comparePassword};
