const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true },
  email: { type: String, required: true, unique: true, lowercase: true, trim: true },
  password: { type: String, required: true, minlength: 6 },
  phone: { type: String, trim: true, default: '' },
  address: { type: String, trim: true, default: '' },
  role: { type: String, enum: ['admin','staff','delivery','customer'], default: 'customer' },
  status: { type: String, enum: ['active','inactive'], default: 'active' },
  permissions: {
    productManagement: { type: Boolean, default: false },
    inventoryManagement: { type: Boolean, default: false },
    orderProcessing: { type: Boolean, default: false },
    customerManagement: { type: Boolean, default: false }
  },
  resetPasswordToken: { type: String, default: null },
  resetPasswordExpires: { type: Date, default: null }
}, { timestamps: true });

module.exports = mongoose.model('User', userSchema);
