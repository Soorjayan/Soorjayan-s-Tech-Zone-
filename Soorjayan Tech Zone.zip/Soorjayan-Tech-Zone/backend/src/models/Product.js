const mongoose = require('mongoose');
const productSchema = new mongoose.Schema({
  name:{type:String,required:true,trim:true,minlength:2},
  brand:{type:String,required:true,trim:true},
  category:{type:String,required:true,trim:true},
  description:{type:String,required:true,trim:true},
  price:{type:Number,required:true,min:0},
  discount:{type:Number,default:0,min:0,max:100},
  stock:{type:Number,required:true,min:0},
  image:{type:String,trim:true},
  specifications:{processor:String,ram:String,storage:String,display:String,graphics:String},
  warranty:{type:String,trim:true},
  supplier:{type:mongoose.Schema.Types.ObjectId,ref:'Supplier',default:null},
  status:{type:String,enum:['active','inactive','out_of_stock'],default:'active'}
},{timestamps:true});
module.exports=mongoose.model('Product',productSchema);
