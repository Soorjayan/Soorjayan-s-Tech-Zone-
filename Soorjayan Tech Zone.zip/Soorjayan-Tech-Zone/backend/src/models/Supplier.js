const mongoose=require('mongoose');
const schema=new mongoose.Schema({name:{type:String,required:true,trim:true},company:{type:String,required:true,trim:true},contactPerson:{type:String,trim:true,default:''},phone:{type:String,trim:true,default:''},email:{type:String,trim:true,lowercase:true,default:''},address:{type:String,trim:true,default:''},suppliedCategories:{type:[String],default:[]},status:{type:String,enum:['active','inactive'],default:'active'}},{timestamps:true});
module.exports=mongoose.model('Supplier',schema);
