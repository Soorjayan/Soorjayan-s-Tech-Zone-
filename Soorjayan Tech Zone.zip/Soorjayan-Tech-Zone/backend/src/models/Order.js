const mongoose = require('mongoose');
const itemSchema = new mongoose.Schema({product:{type:mongoose.Schema.Types.ObjectId,ref:'Product',required:true},name:{type:String,required:true},price:{type:Number,required:true,min:0},quantity:{type:Number,required:true,min:1},subtotal:{type:Number,required:true,min:0}},{_id:false});
const paymentHistorySchema = new mongoose.Schema({status:{type:String,enum:['PENDING','PAID','FAILED'],required:true},note:{type:String,default:''},updatedBy:{type:mongoose.Schema.Types.ObjectId,ref:'User'},updatedAt:{type:Date,default:Date.now}},{_id:false});
const orderSchema = new mongoose.Schema({
 user:{type:mongoose.Schema.Types.ObjectId,ref:'User',required:true},items:{type:[itemSchema],required:true},
 shippingAddress:{name:{type:String,required:true},phone:{type:String,required:true},address:{type:String,required:true}},
 paymentMethod:{type:String,enum:['COD','BANK_TRANSFER'],default:'COD'},paymentStatus:{type:String,enum:['PENDING','PAID','FAILED'],default:'PENDING'},
 paymentHistory:{type:[paymentHistorySchema],default:[]},
 orderStatus:{type:String,enum:['PLACED','CONFIRMED','PROCESSING','SHIPPED','OUT_FOR_DELIVERY','DELIVERED','CANCELLED'],default:'PLACED'},
 assignedDeliveryStaff:{type:mongoose.Schema.Types.ObjectId,ref:'User',default:null},
 subtotal:{type:Number,required:true,min:0},deliveryFee:{type:Number,default:0,min:0},totalAmount:{type:Number,required:true,min:0}
},{timestamps:true});
module.exports=mongoose.model('Order',orderSchema);
