const User=require('../models/User');
const getProfile=async(req,res)=>{const u=await User.findById(req.user.id).select('-password -resetPasswordToken -resetPasswordExpires');res.json({success:true,data:u});};
const updateProfile=async(req,res)=>{try{const allowed=['name','phone','address'];const data={};allowed.forEach(k=>{if(req.body[k]!==undefined)data[k]=req.body[k]});const u=await User.findByIdAndUpdate(req.user.id,data,{new:true,runValidators:true}).select('-password -resetPasswordToken -resetPasswordExpires');res.json({success:true,message:'Profile updated successfully',data:u});}catch(e){res.status(400).json({success:false,message:e.message});}};
module.exports={getProfile,updateProfile};
