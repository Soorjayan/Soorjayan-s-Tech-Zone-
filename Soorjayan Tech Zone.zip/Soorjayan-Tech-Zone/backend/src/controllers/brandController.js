const mongoose = require("mongoose");
const Brand = require("../models/Brand");
const Product = require("../models/Product");

const validateId = (id, res) => {
    if (!mongoose.isValidObjectId(id)) {
        res.status(400).json({ success: false, message: "Invalid brand ID" });
        return false;
    }
    return true;
};

const getProductCounts = async (brands) => {
    if (!brands.length) return new Map();
    const names = brands.map((brand) => brand.name);
    const rows = await Product.aggregate([
        { $match: { brand: { $in: names } } },
        { $group: { _id: "$brand", productCount: { $sum: 1 } } }
    ]);
    return new Map(rows.map((row) => [row._id, row.productCount]));
};

exports.createBrand = async (req, res) => {
    try {
        const brand = await Brand.create(req.body);
        return res.status(201).json({ success: true, message: "Brand created successfully", data: { ...brand.toObject(), productCount: 0 } });
    } catch (error) {
        if (error.code === 11000) return res.status(400).json({ success: false, message: "A brand with this name already exists" });
        return res.status(400).json({ success: false, message: error.message });
    }
};

exports.getBrands = async (req, res) => {
    try {
        const { search = "", status, page = 1, limit = 10, sort = "newest" } = req.query;
        const currentPage = Math.max(parseInt(page, 10) || 1, 1);
        const perPage = Math.min(Math.max(parseInt(limit, 10) || 10, 1), 100);
        const filter = {};

        if (search.trim()) filter.name = new RegExp(search.trim(), "i");
        if (status) {
            if (!["active", "inactive"].includes(status)) return res.status(400).json({ success: false, message: "Status must be active or inactive" });
            filter.status = status;
        }

        const sortMap = {
            newest: { createdAt: -1 },
            oldest: { createdAt: 1 },
            name_asc: { name: 1 },
            name_desc: { name: -1 }
        };
        if (!sortMap[sort]) return res.status(400).json({ success: false, message: "Invalid sort option", allowedSorts: Object.keys(sortMap) });

        const skip = (currentPage - 1) * perPage;
        const [brands, totalBrands] = await Promise.all([
            Brand.find(filter).sort(sortMap[sort]).skip(skip).limit(perPage).lean(),
            Brand.countDocuments(filter)
        ]);
        const counts = await getProductCounts(brands);
        const data = brands.map((brand) => ({ ...brand, productCount: counts.get(brand.name) || 0 }));
        const totalPages = Math.ceil(totalBrands / perPage);

        return res.json({
            success: true,
            count: data.length,
            totalBrands,
            pagination: { page: currentPage, limit: perPage, totalPages, hasNextPage: currentPage < totalPages, hasPreviousPage: currentPage > 1 },
            filters: { search, status: status || null, sort },
            data
        });
    } catch (error) {
        return res.status(500).json({ success: false, message: "Failed to fetch brands", error: error.message });
    }
};

exports.getBrandStats = async (req, res) => {
    try {
        const [summary, statusBreakdown] = await Promise.all([
            Brand.aggregate([{ $group: {
                _id: null,
                totalBrands: { $sum: 1 },
                activeBrands: { $sum: { $cond: [{ $eq: ["$status", "active"] }, 1, 0] } },
                inactiveBrands: { $sum: { $cond: [{ $eq: ["$status", "inactive"] }, 1, 0] } }
            } }]),
            Brand.aggregate([{ $group: { _id: "$status", count: { $sum: 1 } } }, { $sort: { _id: 1 } }])
        ]);
        const base = summary[0] || { totalBrands: 0, activeBrands: 0, inactiveBrands: 0 };
        return res.json({ success: true, data: { summary: base, statusBreakdown } });
    } catch (error) {
        return res.status(500).json({ success: false, message: "Failed to fetch brand statistics", error: error.message });
    }
};

exports.getBrandById = async (req, res) => {
    try {
        if (!validateId(req.params.id, res)) return;
        const brand = await Brand.findById(req.params.id).lean();
        if (!brand) return res.status(404).json({ success: false, message: "Brand not found" });
        const products = await Product.find({ brand: brand.name }).select("name brand category price stock status supplier").sort({ name: 1 });
        return res.json({ success: true, data: { brand, productCount: products.length, products } });
    } catch (error) {
        return res.status(500).json({ success: false, message: "Failed to fetch brand", error: error.message });
    }
};

exports.updateBrand = async (req, res) => {
    try {
        if (!validateId(req.params.id, res)) return;
        const current = await Brand.findById(req.params.id);
        if (!current) return res.status(404).json({ success: false, message: "Brand not found" });

        const oldName = current.name;
        const newName = req.body.name !== undefined ? String(req.body.name).trim() : oldName;
        if (!newName) return res.status(400).json({ success: false, message: "Brand name cannot be empty" });
        const duplicate = await Brand.findOne({ name: newName, _id: { $ne: current._id } });
        if (duplicate) return res.status(400).json({ success: false, message: "A brand with this name already exists" });

        current.set(req.body);
        current.name = newName;
        await current.save();

        let productsUpdated = 0;
        if (oldName !== newName) {
            const result = await Product.updateMany({ brand: oldName }, { $set: { brand: newName } });
            productsUpdated = result.modifiedCount || 0;
        }

        return res.json({ success: true, message: "Brand updated successfully", productsUpdated, data: current });
    } catch (error) {
        if (error.code === 11000) return res.status(400).json({ success: false, message: "A brand with this name already exists" });
        return res.status(400).json({ success: false, message: error.message });
    }
};

exports.updateBrandStatus = async (req, res) => {
    try {
        if (!validateId(req.params.id, res)) return;
        const { status } = req.body;
        if (!["active", "inactive"].includes(status)) return res.status(400).json({ success: false, message: "Status must be active or inactive" });
        const brand = await Brand.findByIdAndUpdate(req.params.id, { status }, { new: true, runValidators: true });
        if (!brand) return res.status(404).json({ success: false, message: "Brand not found" });
        return res.json({ success: true, message: `Brand ${status === "active" ? "activated" : "deactivated"} successfully`, data: brand });
    } catch (error) {
        return res.status(500).json({ success: false, message: "Failed to update brand status", error: error.message });
    }
};

exports.deleteBrand = async (req, res) => {
    try {
        if (!validateId(req.params.id, res)) return;
        const brand = await Brand.findById(req.params.id);
        if (!brand) return res.status(404).json({ success: false, message: "Brand not found" });
        const linkedProductCount = await Product.countDocuments({ brand: brand.name });
        if (linkedProductCount > 0) {
            return res.status(409).json({
                success: false,
                message: "Cannot delete brand while products use it",
                linkedProductCount,
                suggestion: "Rename/reassign the products or deactivate the brand instead"
            });
        }
        await brand.deleteOne();
        return res.json({ success: true, message: "Brand deleted successfully" });
    } catch (error) {
        return res.status(500).json({ success: false, message: "Failed to delete brand", error: error.message });
    }
};
