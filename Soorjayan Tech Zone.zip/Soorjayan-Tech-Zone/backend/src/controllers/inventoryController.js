const Product=require('../models/Product');const StockMovement=require('../models/StockMovement');const THRESHOLD=5;
const list=async(req,res)=>{const f={};if(req.query.status)f.status=req.query.status;if(req.query.search)f.name={$regex:req.query.search,$options:'i'};const data=await Product.find(f).populate('supplier','name company');res.json({success:true,count:data.length,threshold:THRESHOLD,data});};
const low=async(req,res)=>{const data=await Product.find({stock:{$gt:0,$lte:THRESHOLD}});res.json({success:true,count:data.length,data});};const out=async(req,res)=>{const data=await Product.find({stock:0});res.json({success:true,count:data.length,data});};
const stats=async(req,res)=>{
 const [s]=await Product.aggregate([
  {$group:{
   _id:null,
   totalProducts:{$sum:1},
   totalUnits:{$sum:'$stock'},
   inventoryValue:{$sum:{$multiply:['$price','$stock']}},
   activeProducts:{$sum:{$cond:[{$eq:['$status','active']},1,0]}},
   inactiveProducts:{$sum:{$cond:[{$eq:['$status','inactive']},1,0]}},
   lowStockProducts:{$sum:{$cond:[{$and:[{$gt:['$stock',0]},{$lte:['$stock',THRESHOLD]}]},1,0]}},
   outOfStockProducts:{$sum:{$cond:[{$eq:['$stock',0]},1,0]}}
  }}
 ]);
 res.json({success:true,data:{threshold:THRESHOLD,summary:s||{totalProducts:0,totalUnits:0,inventoryValue:0,activeProducts:0,inactiveProducts:0,lowStockProducts:0,outOfStockProducts:0}}});
};
const movements=async(req,res)=>res.json({success:true,count:await StockMovement.countDocuments(),data:await StockMovement.find().populate('product','name').populate('performedBy','name email').sort({createdAt:-1})});
const change=async(req,res)=>{try{const p=await Product.findById(req.params.productId);if(!p)return res.status(404).json({success:false,message:'Product not found'});const qty=Number(req.body.quantity);if(!Number.isInteger(qty)||qty<1)return res.status(400).json({success:false,message:'Quantity must be a positive integer'});const before=p.stock;let after=before,type,direction;if(req.path.endsWith('add-stock')){after+=qty;type='RESTOCK';direction='ADD';}else if(req.path.endsWith('reduce-stock')){if(before<qty)return res.status(400).json({success:false,message:'Insufficient stock'});after-=qty;type='ADJUSTMENT';direction='REMOVE';}else{after=Number(req.body.stock);if(!Number.isInteger(after)||after<0)return res.status(400).json({success:false,message:'Valid target stock is required'});qty=Math.abs(after-before);if(!qty)return res.json({success:true,message:'No stock change required',data:p});type='ADJUSTMENT';direction=after>before?'ADD':'REMOVE';}p.stock=after;if(p.stock===0&&p.status==='active')p.status='out_of_stock';if(p.stock>0&&p.status==='out_of_stock')p.status='active';await p.save();await StockMovement.create({product:p._id,type,direction,quantity:qty,stockBefore:before,stockAfter:after,performedBy:req.user.id,note:req.body.note||''});res.json({success:true,message:'Stock updated successfully',data:p});}catch(e){res.status(400).json({success:false,message:e.message});}};
const history=async(req,res)=>res.json({success:true,count:await StockMovement.countDocuments({product:req.params.productId}),data:await StockMovement.find({product:req.params.productId}).populate('performedBy','name email').sort({createdAt:-1})});
module.exports={list,low,out,stats,movements,change,history};
