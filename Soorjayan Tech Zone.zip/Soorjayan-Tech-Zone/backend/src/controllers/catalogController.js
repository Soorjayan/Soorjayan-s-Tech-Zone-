const Supplier=require('../models/Supplier');const Category=require('../models/Category');const Brand=require('../models/Brand');const Product=require('../models/Product');
const paginate=async(Model,req,roleField)=>{const {search='',status,page=1,limit=10,sort='newest'}=req.query;const f={};if(status)f.status=status;if(search)f.name={$regex:search,$options:'i'};const p=Math.max(+page||1,1),l=Math.min(Math.max(+limit||10,1),100);const so=sort==='oldest'?{createdAt:1}:{createdAt:-1};const [data,total]=await Promise.all([Model.find(f).sort(so).skip((p-1)*l).limit(l),Model.countDocuments(f)]);return {data,total,p,l};};
const supplierList=async(req,res)=>{try{const x=await paginate(Supplier,req);const data=await Promise.all(x.data.map(async s=>{const productCount=await Product.countDocuments({supplier:s._id});return {...s.toObject(),productCount};}));res.json({success:true,count:data.length,totalSuppliers:x.total,pagination:{page:x.p,limit:x.l,totalPages:Math.ceil(x.total/x.l),hasNextPage:x.p*x.l<x.total,hasPreviousPage:x.p>1},filters:{search:req.query.search||'',status:req.query.status||null,sort:req.query.sort||'newest'},data});}catch(e){res.status(500).json({success:false,message:e.message});}};
const supplierCreate=async(req,res)=>{try{const s=await Supplier.create(req.body);res.status(201).json({success:true,message:'Supplier created successfully',data:s});}catch(e){res.status(400).json({success:false,message:e.message});}};
const supplierGet=async(req,res)=>{const s=await Supplier.findById(req.params.id);if(!s)return res.status(404).json({success:false,message:'Supplier not found'});const products=await Product.find({supplier:s._id}).select('name brand category price stock status');res.json({success:true,data:{supplier:s,productCount:products.length,products}});};
const supplierUpdate=async(req,res)=>{const s=await Supplier.findByIdAndUpdate(req.params.id,req.body,{new:true,runValidators:true});if(!s)return res.status(404).json({success:false,message:'Supplier not found'});res.json({success:true,message:'Supplier updated successfully',data:s});};
const supplierStatus=async(req,res)=>{const s=await Supplier.findByIdAndUpdate(req.params.id,{status:req.body.status},{new:true,runValidators:true});if(!s)return res.status(404).json({success:false,message:'Supplier not found'});res.json({success:true,message:`Supplier ${req.body.status==='active'?'activated':'deactivated'} successfully`,data:s});};
const supplierDelete=async(req,res)=>{const n=await Product.countDocuments({supplier:req.params.id});if(n)return res.status(400).json({success:false,message:'Cannot delete supplier while products are linked to it',linkedProductCount:n,suggestion:'Unlink the products or deactivate the supplier instead'});const s=await Supplier.findByIdAndDelete(req.params.id);if(!s)return res.status(404).json({success:false,message:'Supplier not found'});res.json({success:true,message:'Supplier deleted successfully',data:s});};
const supplierStats=async(req,res)=>{
  const [summary]=await Supplier.aggregate([
    {$group:{
      _id:null,
      totalSuppliers:{$sum:1},
      activeSuppliers:{$sum:{$cond:[{$eq:['$status','active']},1,0]}},
      inactiveSuppliers:{$sum:{$cond:[{$eq:['$status','inactive']},1,0]}}
    }}
  ]);
  res.json({success:true,data:{summary:summary||{totalSuppliers:0,activeSuppliers:0,inactiveSuppliers:0}}});
};
const genericList=async(Model,req,res,label)=>{label=label||Model.modelName.toLowerCase();try{const x=await paginate(Model,req);const data=await Promise.all(x.data.map(async d=>({...d.toObject(),productCount:await Product.countDocuments(label==='category'?{category:d.name}:{brand:d.name})})));res.json({success:true,count:data.length,[`total${label==='category'?'Categories':'Brands'}`]:x.total,pagination:{page:x.p,limit:x.l,totalPages:Math.ceil(x.total/x.l),hasNextPage:x.p*x.l<x.total,hasPreviousPage:x.p>1},filters:{search:req.query.search||'',status:req.query.status||null,sort:req.query.sort||'newest'},data});}catch(e){res.status(500).json({success:false,message:e.message});}};
const genericCreate=async(Model,req,res,label)=>{try{const d=await Model.create(req.body);res.status(201).json({success:true,message:`${label} created successfully`,data:{...d.toObject(),productCount:0}});}catch(e){res.status(400).json({success:false,message:e.message});}};
const genericGet=async(Model,req,res,label)=>{const d=await Model.findById(req.params.id);if(!d)return res.status(404).json({success:false,message:`${label} not found`});const products=await Product.find(label==='Category'?{category:d.name}:{brand:d.name}).select('name brand category price stock status supplier');res.json({success:true,data:{[label.toLowerCase()]:d,productCount:products.length,products}});};
const genericStats=async(Model,res,label)=>{
  const [summary]=await Model.aggregate([
    {
      $group:{
        _id:null,
        total:{$sum:1},
        active:{$sum:{$cond:[{$eq:['$status','active']},1,0]}},
        inactive:{$sum:{$cond:[{$eq:['$status','inactive']},1,0]}}
      }
    }
  ]);
  const statusBreakdown=await Model.aggregate([{$group:{_id:'$status',count:{$sum:1}}},{$sort:{_id:1}}]);
  const p=label==='Category'?'Categories':'Brands';
  res.json({success:true,data:{summary:{_id:null,[`total${p}`]:summary?.total||0,[`active${p}`]:summary?.active||0,[`inactive${p}`]:summary?.inactive||0},statusBreakdown}});
};
const genericUpdate=async(Model,req,res,label)=>{try{const old=await Model.findById(req.params.id);if(!old)return res.status(404).json({success:false,message:`${label} not found`});const oldName=old.name;const d=await Model.findByIdAndUpdate(req.params.id,req.body,{new:true,runValidators:true});let productsUpdated=0;if(req.body.name&&req.body.name!==oldName){const f=label==='Category'?{category:oldName}:{brand:oldName};const u=label==='Category'?{category:req.body.name}:{brand:req.body.name};const r=await Product.updateMany(f,u);productsUpdated=r.modifiedCount;}res.json({success:true,message:`${label} updated successfully`,productsUpdated,data:d});}catch(e){res.status(400).json({success:false,message:e.message});}};
const genericStatus=async(Model,req,res,label)=>{if(!['active','inactive'].includes(req.body.status))return res.status(400).json({success:false,message:'Invalid status'});const d=await Model.findByIdAndUpdate(req.params.id,{status:req.body.status},{new:true});if(!d)return res.status(404).json({success:false,message:`${label} not found`});res.json({success:true,message:`${label} ${req.body.status==='active'?'activated':'deactivated'} successfully`,data:d});};
const genericDelete=async(Model,req,res,label)=>{const d=await Model.findById(req.params.id);if(!d)return res.status(404).json({success:false,message:`${label} not found`});const n=await Product.countDocuments(label==='Category'?{category:d.name}:{brand:d.name});if(n)return res.status(400).json({success:false,message:`Cannot delete ${label.toLowerCase()} while products use it`,linkedProductCount:n,suggestion:'Rename/reassign the products or deactivate the '+label.toLowerCase()+' instead'});await d.deleteOne();res.json({success:true,message:`${label} deleted successfully`,data:d});};
module.exports={supplierList,supplierCreate,supplierGet,supplierUpdate,supplierStatus,supplierDelete,supplierStats,genericList,genericCreate,genericGet,genericStats,genericUpdate,genericStatus,genericDelete};
