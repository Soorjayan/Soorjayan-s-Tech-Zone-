const mongoose = require("mongoose");
const Supplier = require("../models/Supplier");
const Product = require("../models/Product");

const normalizeCategories = (categories) => {
    if (!categories) return undefined;
    if (Array.isArray(categories)) return categories.map((item) => String(item).trim()).filter(Boolean);
    return String(categories).split(",").map((item) => item.trim()).filter(Boolean);
};

const validateSupplierId = (id, res) => {
    if (!mongoose.Types.ObjectId.isValid(id)) {
        res.status(400).json({ success: false, message: "Invalid supplier ID" });
        return false;
    }
    return true;
};

// POST /api/suppliers
exports.createSupplier = async (req, res) => {
    try {
        const payload = { ...req.body };
        const categories = normalizeCategories(payload.suppliedCategories);
        if (categories !== undefined) payload.suppliedCategories = categories;

        const supplier = await Supplier.create(payload);

        return res.status(201).json({
            success: true,
            message: "Supplier created successfully",
            data: supplier
        });
    } catch (error) {
        if (error.code === 11000) {
            return res.status(400).json({
                success: false,
                message: "A supplier with this email already exists"
            });
        }

        return res.status(400).json({
            success: false,
            message: error.message
        });
    }
};

// GET /api/suppliers
exports.getSuppliers = async (req, res) => {
    try {
        const {
            search = "",
            status,
            category,
            page = 1,
            limit = 10,
            sort = "newest"
        } = req.query;

        const currentPage = Math.max(parseInt(page, 10) || 1, 1);
        const perPage = Math.min(Math.max(parseInt(limit, 10) || 10, 1), 100);

        const filter = {};

        if (search.trim()) {
            const regex = new RegExp(search.trim(), "i");
            filter.$or = [
                { name: regex },
                { companyName: regex },
                { contactPerson: regex },
                { email: regex },
                { phone: regex }
            ];
        }

        if (status) {
            if (!["active", "inactive"].includes(status)) {
                return res.status(400).json({
                    success: false,
                    message: "Status must be active or inactive"
                });
            }
            filter.status = status;
        }

        if (category) {
            filter.suppliedCategories = new RegExp(`^${category.trim()}$`, "i");
        }

        const sortMap = {
            newest: { createdAt: -1 },
            oldest: { createdAt: 1 },
            name_asc: { name: 1 },
            name_desc: { name: -1 },
            company_asc: { companyName: 1 },
            company_desc: { companyName: -1 }
        };

        if (!sortMap[sort]) {
            return res.status(400).json({
                success: false,
                message: "Invalid sort option",
                allowedSorts: Object.keys(sortMap)
            });
        }

        const skip = (currentPage - 1) * perPage;
        const [suppliers, totalSuppliers] = await Promise.all([
            Supplier.find(filter)
                .sort(sortMap[sort])
                .skip(skip)
                .limit(perPage),
            Supplier.countDocuments(filter)
        ]);

        const totalPages = Math.ceil(totalSuppliers / perPage);

        return res.json({
            success: true,
            count: suppliers.length,
            totalSuppliers,
            pagination: {
                page: currentPage,
                limit: perPage,
                totalPages,
                hasNextPage: currentPage < totalPages,
                hasPreviousPage: currentPage > 1
            },
            filters: {
                search,
                status: status || null,
                category: category || null,
                sort
            },
            data: suppliers
        });
    } catch (error) {
        return res.status(500).json({
            success: false,
            message: "Failed to fetch suppliers",
            error: error.message
        });
    }
};

// GET /api/suppliers/stats
exports.getSupplierStats = async (req, res) => {
    try {
        const [summary, categoryBreakdown, topSuppliers] = await Promise.all([
            Supplier.aggregate([
                {
                    $group: {
                        _id: null,
                        totalSuppliers: { $sum: 1 },
                        activeSuppliers: {
                            $sum: { $cond: [{ $eq: ["$status", "active"] }, 1, 0] }
                        },
                        inactiveSuppliers: {
                            $sum: { $cond: [{ $eq: ["$status", "inactive"] }, 1, 0] }
                        }
                    }
                }
            ]),
            Supplier.aggregate([
                { $unwind: { path: "$suppliedCategories", preserveNullAndEmptyArrays: false } },
                { $group: { _id: "$suppliedCategories", count: { $sum: 1 } } },
                { $sort: { count: -1, _id: 1 } }
            ]),
            Supplier.find({ status: "active" }).sort({ createdAt: -1 }).limit(5).lean()
        ]);

        const baseSummary = summary[0] || {
            totalSuppliers: 0,
            activeSuppliers: 0,
            inactiveSuppliers: 0
        };

        const supplierIds = topSuppliers.map((supplier) => supplier._id);
        const productCounts = supplierIds.length
            ? await Product.aggregate([
                { $match: { supplier: { $in: supplierIds } } },
                { $group: { _id: "$supplier", productCount: { $sum: 1 } } }
            ])
            : [];

        const countMap = new Map(productCounts.map((item) => [String(item._id), item.productCount]));

        return res.json({
            success: true,
            data: {
                summary: {
                    totalSuppliers: baseSummary.totalSuppliers,
                    activeSuppliers: baseSummary.activeSuppliers,
                    inactiveSuppliers: baseSummary.inactiveSuppliers
                },
                categoryBreakdown,
                recentActiveSuppliers: topSuppliers.map((supplier) => ({
                    ...supplier,
                    productCount: countMap.get(String(supplier._id)) || 0
                }))
            }
        });
    } catch (error) {
        return res.status(500).json({
            success: false,
            message: "Failed to fetch supplier statistics",
            error: error.message
        });
    }
};

// GET /api/suppliers/:id
exports.getSupplierById = async (req, res) => {
    try {
        if (!validateSupplierId(req.params.id, res)) return;

        const supplier = await Supplier.findById(req.params.id);

        if (!supplier) {
            return res.status(404).json({
                success: false,
                message: "Supplier not found"
            });
        }

        const products = await Product.find({ supplier: supplier._id })
            .select("name brand category price stock status")
            .sort({ name: 1 });

        return res.json({
            success: true,
            data: {
                supplier,
                productCount: products.length,
                products
            }
        });
    } catch (error) {
        return res.status(500).json({
            success: false,
            message: "Failed to fetch supplier",
            error: error.message
        });
    }
};

// PUT /api/suppliers/:id
exports.updateSupplier = async (req, res) => {
    try {
        if (!validateSupplierId(req.params.id, res)) return;

        const payload = { ...req.body };
        const categories = normalizeCategories(payload.suppliedCategories);
        if (categories !== undefined) payload.suppliedCategories = categories;

        const supplier = await Supplier.findByIdAndUpdate(
            req.params.id,
            payload,
            { new: true, runValidators: true }
        );

        if (!supplier) {
            return res.status(404).json({
                success: false,
                message: "Supplier not found"
            });
        }

        return res.json({
            success: true,
            message: "Supplier updated successfully",
            data: supplier
        });
    } catch (error) {
        if (error.code === 11000) {
            return res.status(400).json({
                success: false,
                message: "A supplier with this email already exists"
            });
        }

        return res.status(400).json({
            success: false,
            message: error.message
        });
    }
};

// PATCH /api/suppliers/:id/status
exports.updateSupplierStatus = async (req, res) => {
    try {
        if (!validateSupplierId(req.params.id, res)) return;

        const { status } = req.body;

        if (!["active", "inactive"].includes(status)) {
            return res.status(400).json({
                success: false,
                message: "Status must be active or inactive"
            });
        }

        const supplier = await Supplier.findByIdAndUpdate(
            req.params.id,
            { status },
            { new: true, runValidators: true }
        );

        if (!supplier) {
            return res.status(404).json({
                success: false,
                message: "Supplier not found"
            });
        }

        return res.json({
            success: true,
            message: `Supplier ${status === "active" ? "activated" : "deactivated"} successfully`,
            data: supplier
        });
    } catch (error) {
        return res.status(500).json({
            success: false,
            message: "Failed to update supplier status",
            error: error.message
        });
    }
};

// DELETE /api/suppliers/:id
exports.deleteSupplier = async (req, res) => {
    try {
        if (!validateSupplierId(req.params.id, res)) return;

        const supplier = await Supplier.findById(req.params.id);

        if (!supplier) {
            return res.status(404).json({
                success: false,
                message: "Supplier not found"
            });
        }

        const linkedProductCount = await Product.countDocuments({ supplier: supplier._id });

        if (linkedProductCount > 0) {
            return res.status(409).json({
                success: false,
                message: "Cannot delete supplier while products are linked to it",
                linkedProductCount,
                suggestion: "Unlink the products or deactivate the supplier instead"
            });
        }

        await supplier.deleteOne();

        return res.json({
            success: true,
            message: "Supplier deleted successfully"
        });
    } catch (error) {
        return res.status(500).json({
            success: false,
            message: "Failed to delete supplier",
            error: error.message
        });
    }
};
