const mongoose = require("mongoose");
const Category = require("../models/Category");
const Product = require("../models/Product");

const validateId = (id, res) => {
    if (!mongoose.isValidObjectId(id)) {
        res.status(400).json({ success: false, message: "Invalid category ID" });
        return false;
    }
    return true;
};

const getProductCounts = async (categories) => {
    if (!categories.length) return new Map();

    const names = categories.map((category) => category.name);
    const rows = await Product.aggregate([
        { $match: { category: { $in: names } } },
        { $group: { _id: "$category", productCount: { $sum: 1 } } }
    ]);

    return new Map(rows.map((row) => [row._id, row.productCount]));
};

exports.createCategory = async (req, res) => {
    try {
        const category = await Category.create(req.body);
        return res.status(201).json({
            success: true,
            message: "Category created successfully",
            data: { ...category.toObject(), productCount: 0 }
        });
    } catch (error) {
        if (error.code === 11000) {
            return res.status(400).json({ success: false, message: "A category with this name already exists" });
        }
        return res.status(400).json({ success: false, message: error.message });
    }
};

exports.getCategories = async (req, res) => {
    try {
        const { search = "", status, page = 1, limit = 10, sort = "newest" } = req.query;
        const currentPage = Math.max(parseInt(page, 10) || 1, 1);
        const perPage = Math.min(Math.max(parseInt(limit, 10) || 10, 1), 100);
        const filter = {};

        if (search.trim()) filter.name = new RegExp(search.trim(), "i");
        if (status) {
            if (!["active", "inactive"].includes(status)) {
                return res.status(400).json({ success: false, message: "Status must be active or inactive" });
            }
            filter.status = status;
        }

        const sortMap = {
            newest: { createdAt: -1 },
            oldest: { createdAt: 1 },
            name_asc: { name: 1 },
            name_desc: { name: -1 }
        };
        if (!sortMap[sort]) {
            return res.status(400).json({ success: false, message: "Invalid sort option", allowedSorts: Object.keys(sortMap) });
        }

        const skip = (currentPage - 1) * perPage;
        const [categories, totalCategories] = await Promise.all([
            Category.find(filter).sort(sortMap[sort]).skip(skip).limit(perPage).lean(),
            Category.countDocuments(filter)
        ]);
        const counts = await getProductCounts(categories);
        const data = categories.map((category) => ({
            ...category,
            productCount: counts.get(category.name) || 0
        }));
        const totalPages = Math.ceil(totalCategories / perPage);

        return res.json({
            success: true,
            count: data.length,
            totalCategories,
            pagination: {
                page: currentPage,
                limit: perPage,
                totalPages,
                hasNextPage: currentPage < totalPages,
                hasPreviousPage: currentPage > 1
            },
            filters: { search, status: status || null, sort },
            data
        });
    } catch (error) {
        return res.status(500).json({ success: false, message: "Failed to fetch categories", error: error.message });
    }
};

exports.getCategoryStats = async (req, res) => {
    try {
        const [summary, statusBreakdown] = await Promise.all([
            Category.aggregate([
                { $group: {
                    _id: null,
                    totalCategories: { $sum: 1 },
                    activeCategories: { $sum: { $cond: [{ $eq: ["$status", "active"] }, 1, 0] } },
                    inactiveCategories: { $sum: { $cond: [{ $eq: ["$status", "inactive"] }, 1, 0] } }
                } }
            ]),
            Category.aggregate([{ $group: { _id: "$status", count: { $sum: 1 } } }, { $sort: { _id: 1 } }])
        ]);

        const base = summary[0] || { totalCategories: 0, activeCategories: 0, inactiveCategories: 0 };
        return res.json({ success: true, data: { summary: base, statusBreakdown } });
    } catch (error) {
        return res.status(500).json({ success: false, message: "Failed to fetch category statistics", error: error.message });
    }
};

exports.getCategoryById = async (req, res) => {
    try {
        if (!validateId(req.params.id, res)) return;
        const category = await Category.findById(req.params.id).lean();
        if (!category) return res.status(404).json({ success: false, message: "Category not found" });

        const products = await Product.find({ category: category.name })
            .select("name brand category price stock status supplier")
            .sort({ name: 1 });

        return res.json({ success: true, data: { category, productCount: products.length, products } });
    } catch (error) {
        return res.status(500).json({ success: false, message: "Failed to fetch category", error: error.message });
    }
};

exports.updateCategory = async (req, res) => {
    try {
        if (!validateId(req.params.id, res)) return;
        const current = await Category.findById(req.params.id);
        if (!current) return res.status(404).json({ success: false, message: "Category not found" });

        const oldName = current.name;
        const newName = req.body.name !== undefined ? String(req.body.name).trim() : oldName;
        if (!newName) return res.status(400).json({ success: false, message: "Category name cannot be empty" });

        const duplicate = await Category.findOne({ name: newName, _id: { $ne: current._id } });
        if (duplicate) return res.status(400).json({ success: false, message: "A category with this name already exists" });

        current.set(req.body);
        current.name = newName;
        await current.save();

        let productsUpdated = 0;
        if (oldName !== newName) {
            const result = await Product.updateMany({ category: oldName }, { $set: { category: newName } });
            productsUpdated = result.modifiedCount || 0;
        }

        return res.json({
            success: true,
            message: "Category updated successfully",
            productsUpdated,
            data: current
        });
    } catch (error) {
        if (error.code === 11000) return res.status(400).json({ success: false, message: "A category with this name already exists" });
        return res.status(400).json({ success: false, message: error.message });
    }
};

exports.updateCategoryStatus = async (req, res) => {
    try {
        if (!validateId(req.params.id, res)) return;
        const { status } = req.body;
        if (!["active", "inactive"].includes(status)) {
            return res.status(400).json({ success: false, message: "Status must be active or inactive" });
        }
        const category = await Category.findByIdAndUpdate(req.params.id, { status }, { new: true, runValidators: true });
        if (!category) return res.status(404).json({ success: false, message: "Category not found" });
        return res.json({ success: true, message: `Category ${status === "active" ? "activated" : "deactivated"} successfully`, data: category });
    } catch (error) {
        return res.status(500).json({ success: false, message: "Failed to update category status", error: error.message });
    }
};

exports.deleteCategory = async (req, res) => {
    try {
        if (!validateId(req.params.id, res)) return;
        const category = await Category.findById(req.params.id);
        if (!category) return res.status(404).json({ success: false, message: "Category not found" });

        const linkedProductCount = await Product.countDocuments({ category: category.name });
        if (linkedProductCount > 0) {
            return res.status(409).json({
                success: false,
                message: "Cannot delete category while products use it",
                linkedProductCount,
                suggestion: "Rename/reassign the products or deactivate the category instead"
            });
        }

        await category.deleteOne();
        return res.json({ success: true, message: "Category deleted successfully" });
    } catch (error) {
        return res.status(500).json({ success: false, message: "Failed to delete category", error: error.message });
    }
};
