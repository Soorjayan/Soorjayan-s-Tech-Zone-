const Order=require('../models/Order');
const updatePaymentStatus=async(req,res)=>{try{const {paymentStatus,note=''}=req.body;if(!['PENDING','PAID','FAILED'].includes(paymentStatus))return res.status(400).json({success:false,message:'Invalid payment status'});const o=await Order.findById(req.params.id);if(!o)return res.status(404).json({success:false,message:'Order not found'});o.paymentStatus=paymentStatus;o.paymentHistory.push({status:paymentStatus,note,updatedBy:req.user.id});await o.save();res.json({success:true,message:'Payment status updated successfully',data:o});}catch(e){res.status(400).json({success:false,message:e.message});}};
const history=async(req,res)=>{const o=await Order.findById(req.params.id).select('paymentMethod paymentStatus paymentHistory totalAmount createdAt');if(!o)return res.status(404).json({success:false,message:'Order not found'});res.json({success:true,data:o});};
const stats=async(req,res)=>{
 const [summary]=await Order.aggregate([{$group:{
  _id:null,totalPayments:{$sum:1},
  pending:{$sum:{$cond:[{$eq:['$paymentStatus','PENDING']},1,0]}},
  paid:{$sum:{$cond:[{$eq:['$paymentStatus','PAID']},1,0]}},
  failed:{$sum:{$cond:[{$eq:['$paymentStatus','FAILED']},1,0]}},
  paidAmount:{$sum:{$cond:[{$eq:['$paymentStatus','PAID']},'$totalAmount',0]}}
 }}]);
 const methods=await Order.aggregate([{$group:{_id:'$paymentMethod',count:{$sum:1},amount:{$sum:'$totalAmount'}}}]);
 res.json({success:true,data:{summary:summary||{totalPayments:0,pending:0,paid:0,failed:0,paidAmount:0},methodBreakdown:methods}});
};
module.exports={updatePaymentStatus,history,stats};
