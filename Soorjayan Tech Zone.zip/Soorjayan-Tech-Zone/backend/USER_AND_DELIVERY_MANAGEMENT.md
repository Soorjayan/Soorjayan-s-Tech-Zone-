# Customer, Staff & Delivery Management

This module completes the remaining backend stakeholder management for Soorjayan's Tech Zone.

## Roles

- `customer`: self-registers and manages own profile.
- `staff`: created and managed by Admin; can view customer information and existing order/product workflows according to route authorization.
- `delivery`: created and managed by Admin; sees assigned deliveries and updates delivery status.
- `admin`: manages customers, staff, delivery staff and delivery assignments.

## Customer endpoints

- `GET /api/users/me` — authenticated profile
- `PUT /api/users/me` — update own name, phone and address
- `GET /api/users/customers` — Admin/Staff customer list with search/status/pagination
- `GET /api/users/customers/:id` — customer details, order count and non-cancelled spending
- `PATCH /api/users/customers/:id/status` — Admin activate/deactivate customer

## Staff endpoints (Admin)

- `GET /api/users/staff?role=staff`
- `GET /api/users/staff?role=delivery`
- `POST /api/users/staff`
- `POST /api/users/delivery`
- `PUT /api/users/staff/:id`
- `PATCH /api/users/staff/:id/status`
- `DELETE /api/users/staff/:id`
- `GET /api/users/stats`

## Delivery endpoints

- `PUT /api/delivery/orders/:id/assign` — Admin assigns active delivery staff
- `PUT /api/delivery/orders/:id/unassign` — Admin removes assignment
- `GET /api/delivery/my-deliveries` — Delivery staff's assigned orders
- `GET /api/delivery/my-deliveries?status=OUT_FOR_DELIVERY`
- `GET /api/delivery/my-stats` — Delivery staff status summary
- `PUT /api/delivery/orders/:id/status` — Delivery staff can set `OUT_FOR_DELIVERY` or `DELIVERED`

## Order integration

`Order` now stores:

- `deliveryStaff` — reference to the assigned delivery user
- `assignedAt` — assignment timestamp

Existing order, inventory, supplier, category and brand modules remain included in this package.

## Important

Do not include `.env`, database credentials, JWT secrets, or `node_modules` in the project archive.
