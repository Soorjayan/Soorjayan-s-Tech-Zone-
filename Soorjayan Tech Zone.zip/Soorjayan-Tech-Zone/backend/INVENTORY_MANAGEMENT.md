# Inventory Management Module

This module extends Soorjayan's Tech Zone with stock management, low-stock monitoring, stock movement history, and inventory statistics.

## Included files

- `src/models/StockMovement.js`
- `src/controllers/inventoryController.js`
- `src/routes/inventoryRoutes.js`
- Updated `src/controllers/orderController.js`
- Updated `server.js`

No `.env` file or `node_modules` is included.

## Route base

All inventory endpoints use:

`/api/inventory`

Authentication uses the existing JWT middleware.

### Roles

| Endpoint group | Admin | Staff |
|---|---:|---:|
| Inventory list | Yes | Yes |
| Low stock | Yes | Yes |
| Out of stock | Yes | Yes |
| Inventory stats | Yes | No |
| Movement list | Yes | Yes |
| Add stock | Yes | Yes |
| Reduce stock | Yes | Yes |
| Adjust to exact stock | Yes | No |
| Product history | Yes | Yes |

## Endpoints

### 1. Inventory list

`GET /api/inventory`

Supported query parameters:

- `search`
- `category`
- `brand`
- `status`
- `lowStock=true`
- `outOfStock=true`
- `minStock`
- `page`
- `limit`
- `sort`

Sort values:

- `newest`
- `oldest`
- `stock_asc`
- `stock_desc`
- `name_asc`
- `name_desc`
- `price_asc`
- `price_desc`

Example:

`GET /api/inventory?lowStock=true&page=1&limit=10`

### 2. Low stock

`GET /api/inventory/low-stock`

Default threshold: 5 units.

Custom threshold:

`GET /api/inventory/low-stock?threshold=10`

Low stock means stock is greater than 0 and less than or equal to the threshold.

### 3. Out of stock

`GET /api/inventory/out-of-stock`

Returns products with stock equal to 0.

### 4. Inventory statistics

`GET /api/inventory/stats`

Admin only.

Returns:

- total products
- total units
- inventory value (`price × stock`)
- active products
- inactive products
- low-stock products
- out-of-stock products
- stock movement breakdown

### 5. Add stock

`PUT /api/inventory/:productId/add-stock`

Body:

```json
{
  "quantity": 10,
  "reason": "RESTOCK",
  "notes": "Supplier delivery"
}
```

Allowed reasons:

- `RESTOCK`
- `RETURN`
- `ADJUSTMENT`
- `INITIAL_STOCK`

### 6. Reduce stock

`PUT /api/inventory/:productId/reduce-stock`

Body:

```json
{
  "quantity": 2,
  "reason": "ADJUSTMENT",
  "notes": "Damaged units removed"
}
```

Allowed reasons:

- `SALE`
- `ADJUSTMENT`

The endpoint never allows stock to become negative.

### 7. Adjust stock

`PUT /api/inventory/:productId/adjust-stock`

Admin only.

Body:

```json
{
  "newStock": 25,
  "notes": "Physical stock count"
}
```

The difference is automatically recorded as ADD or REMOVE with reason `ADJUSTMENT`.

### 8. All stock movements

`GET /api/inventory/movements`

Query parameters:

- `productId`
- `type=ADD|REMOVE`
- `reason`
- `page`
- `limit`

### 9. Product stock history

`GET /api/inventory/:productId/history`

Query parameters:

- `type`
- `reason`
- `page`
- `limit`

## Automatic order integration

The order module has also been updated.

### When an order is created

For every ordered product:

- product stock is decreased
- product status becomes `out_of_stock` when stock reaches 0
- a `REMOVE` stock movement is recorded
- movement reason is `SALE`
- movement reference is the created order

### When an order is cancelled

For every ordered product:

- reserved stock is restored
- `out_of_stock` changes back to `active` when stock becomes positive
- an `ADD` stock movement is recorded
- movement reason is `CANCELLATION`
- movement reference is the cancelled order

Stock changes and their movement records are written inside the same MongoDB transaction.

## Product status behavior

The existing Product model uses:

- `active`
- `inactive`
- `out_of_stock`

Inventory operations automatically set `out_of_stock` when stock reaches zero.

When stock is increased from zero, an `out_of_stock` product is changed back to `active`.

An explicitly `inactive` product is not automatically changed to active by an inventory update unless it was previously `out_of_stock`.

## Postman testing order

1. Login as admin or staff and copy the JWT.
2. Set:
   `Authorization: Bearer <JWT>`
3. Get inventory:
   `GET http://localhost:5000/api/inventory`
4. Find a product ID.
5. Add stock:
   `PUT http://localhost:5000/api/inventory/<PRODUCT_ID>/add-stock`
6. Check product history:
   `GET http://localhost:5000/api/inventory/<PRODUCT_ID>/history`
7. Check low stock:
   `GET http://localhost:5000/api/inventory/low-stock`
8. Reduce stock:
   `PUT http://localhost:5000/api/inventory/<PRODUCT_ID>/reduce-stock`
9. Check movement list:
   `GET http://localhost:5000/api/inventory/movements`
10. As admin, check statistics:
   `GET http://localhost:5000/api/inventory/stats`
11. Create a customer order and verify a `SALE` movement.
12. Cancel a cancellable order and verify a `CANCELLATION` movement.

## Important

Use the existing project `.env` file. This module does not change the MongoDB connection string or JWT secret.

Do not upload `node_modules` or `.env` to the repository.
