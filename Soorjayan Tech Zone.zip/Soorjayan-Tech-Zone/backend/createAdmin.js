const dns = require("dns");

// Use Google DNS for MongoDB SRV resolution
dns.setServers([
    "8.8.8.8",
    "8.8.4.4"
]);

require("dotenv").config();

const mongoose = require("mongoose");
const User = require("./src/models/User");

const createAdmin = async () => {
    try {
        // Connect to MongoDB
        await mongoose.connect(process.env.MONGO_URI);

        console.log("MongoDB connected");

        const email = "admin@soorjayantechzone.com";
        const password = "Admin@12345";

        // Find existing admin
        let admin = await User.findOne({ email });

        if (admin) {

            // Reset admin details
            admin.name = "Soorjayan Admin";

            // IMPORTANT:
            // Give the plain password here.
            // User.js pre-save hook will hash it automatically.
            admin.password = password;

            admin.role = "admin";
            admin.isActive = true;

            await admin.save();

            console.log("Admin already existed.");
            console.log("Admin password has been reset.");

        } else {

            // IMPORTANT:
            // Give plain password.
            // User.js pre-save hook hashes it automatically.
            admin = await User.create({
                name: "Soorjayan Admin",
                email: email,
                password: password,
                role: "admin",
                isActive: true
            });

            console.log("Admin created successfully!");
        }

        console.log("Email:", email);
        console.log("Role:", admin.role);

        await mongoose.connection.close();

        process.exit(0);

    } catch (error) {

        console.error(
            "Error creating admin:",
            error.message
        );

        await mongoose.connection.close();

        process.exit(1);
    }
};

createAdmin();