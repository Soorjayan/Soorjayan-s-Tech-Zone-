require("dotenv").config();

const express = require("express");
const dns = require("dns");

const cartRoutes = require("./src/routes/cartRoutes");
const orderRoutes = require("./src/routes/orderRoutes");
const inventoryRoutes = require("./src/routes/inventoryRoutes");
const supplierRoutes = require("./src/routes/supplierRoutes");
const categoryRoutes = require("./src/routes/categoryRoutes");
const brandRoutes = require("./src/routes/brandRoutes");
const productRoutes = require("./src/routes/productRoutes");
const authRoutes = require("./src/routes/authRoutes");

// Additional management routes used by the frontend
const customerRoutes = require("./src/routes/customerRoutes");
const staffRoutes = require("./src/routes/staffRoutes");
const deliveryRoutes = require("./src/routes/deliveryRoutes");
const paymentRoutes = require("./src/routes/paymentRoutes");
const profileRoutes = require("./src/routes/profileRoutes");
const dashboardRoutes = require("./src/routes/dashboardRoutes");

const connectDB = require("./src/config/db");

const app = express();
const PORT = process.env.PORT || 5000;

// Use Google DNS for MongoDB SRV resolution.
dns.setServers([
    "8.8.8.8",
    "8.8.4.4"
]);

connectDB();

// Middleware
app.use(express.json());

// CORS for the Vite/React frontend during local development.
// No external cors package is required.
app.use((req, res, next) => {
    const allowedOrigins = [
        "http://localhost:5173",
        "http://127.0.0.1:5173",
        "http://localhost:3000",
        "http://127.0.0.1:3000"
    ];

    const origin = req.headers.origin;

    if (origin && allowedOrigins.includes(origin)) {
        res.header("Access-Control-Allow-Origin", origin);
    }

    res.header("Vary", "Origin");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept, Authorization");
    res.header("Access-Control-Allow-Methods", "GET, POST, PUT, PATCH, DELETE, OPTIONS");

    if (req.method === "OPTIONS") {
        return res.sendStatus(204);
    }

    next();
});

// Core routes
app.use("/api/auth", authRoutes);
app.use("/api/products", productRoutes);
app.use("/api/cart", cartRoutes);
app.use("/api/orders", orderRoutes);
app.use("/api/inventory", inventoryRoutes);
app.use("/api/suppliers", supplierRoutes);
app.use("/api/categories", categoryRoutes);
app.use("/api/brands", brandRoutes);

// Management routes
app.use("/api/customers", customerRoutes);
app.use("/api/staff", staffRoutes);
app.use("/api/delivery-staff", deliveryRoutes);
app.use("/api/payments", paymentRoutes);
app.use("/api/profile", profileRoutes);
app.use("/api/dashboard", dashboardRoutes);

// Health/home
app.get("/", (req, res) => {
    res.json({
        success: true,
        message: "Welcome to Soorjayan's Tech Zone API"
    });
});

app.get("/api/health", (req, res) => {
    res.json({
        success: true,
        message: "API is running"
    });
});

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
