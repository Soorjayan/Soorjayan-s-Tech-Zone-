# Supplier Management Module

This module adds Admin-only supplier management to Soorjayan's Tech Zone.

## Supplier role model

Suppliers do **not** have login accounts. They are business records managed by the Admin.

## Supplier fields

- `name` - required supplier name
- `companyName` - optional company/business name
- `contactPerson` - required contact person
- `phone` - required phone number
- `email` - optional email address
- `address` - required address
- `suppliedCategories` - array of product categories
- `notes` - optional notes
- `status` - `active` or `inactive`

## Product integration

Products now support an optional `supplier` reference. Existing products remain valid with `supplier: null` until linked to a supplier.

## Authentication

Every supplier endpoint requires an Admin JWT:

`Authorization: Bearer <ADMIN_TOKEN>`

Customers, shop staff, and delivery staff cannot manage suppliers.

## Endpoints

### Create supplier

`POST /api/suppliers`

Example:

```json
{
  "name": "Tech Distributors Lanka",
  "companyName": "Tech Distributors Lanka (Pvt) Ltd",
  "contactPerson": "Kamal Perera",
  "phone": "0771234567",
  "email": "kamal@techdistributors.lk",
  "address": "Colombo, Sri Lanka",
  "suppliedCategories": ["Laptops", "Accessories"],
  "notes": "Main electronics supplier",
  "status": "active"
}
```

### List suppliers

`GET /api/suppliers`

Supported query parameters:

- `search`
- `status=active|inactive`
- `category`
- `page`
- `limit`
- `sort=newest|oldest|name_asc|name_desc|company_asc|company_desc`

Example:

`GET /api/suppliers?search=Tech&status=active&page=1&limit=10&sort=name_asc`

### Supplier statistics

`GET /api/suppliers/stats`

Returns supplier totals, active/inactive breakdown, category breakdown, and recent active suppliers with linked product counts.

### Supplier details

`GET /api/suppliers/:id`

Returns supplier information and products linked through the Product `supplier` field.

### Update supplier

`PUT /api/suppliers/:id`

Accepts any editable supplier fields.

### Update status

`PATCH /api/suppliers/:id/status`

Body:

```json
{
  "status": "inactive"
}
```

### Delete supplier

`DELETE /api/suppliers/:id`

A supplier cannot be deleted while products are linked to it. Deactivate it instead, or unlink the products first.

## Recommended Postman test sequence

1. Admin login
2. Create supplier
3. Get all suppliers
4. Search supplier
5. Filter by status
6. Filter by category
7. Get supplier statistics
8. Get supplier by ID
9. Update supplier
10. Change supplier status
11. Link a product to the supplier through the Product update API
12. Get supplier by ID again and verify linked products
13. Attempt deletion while linked and verify the protected `409` response
14. Unlink the product
15. Delete supplier

## Server route

The module is mounted at:

`/api/suppliers`
