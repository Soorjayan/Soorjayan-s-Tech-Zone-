export const getTheme = () => {
  try { return localStorage.getItem("techzone_theme") || "light"; }
  catch { return "light"; }
};

export const setTheme = (theme) => {
  const value = theme === "dark" ? "dark" : "light";
  document.documentElement.dataset.theme = value;
  try { localStorage.setItem("techzone_theme", value); } catch {}
  window.dispatchEvent(new CustomEvent("techzone-theme-updated", { detail: { theme: value } }));
  return value;
};
