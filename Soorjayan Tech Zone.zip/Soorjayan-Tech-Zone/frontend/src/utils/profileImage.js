const prefix = "techzone_profile_picture_";

function keyFor(user) {
  return `${prefix}${user?._id || user?.id || user?.email || "current"}`;
}

export function getProfileImage(user) {
  if (!user) return "";
  try {
    return localStorage.getItem(keyFor(user)) || "";
  } catch {
    return "";
  }
}

export function setProfileImage(user, value) {
  if (!user) return;
  try {
    if (value) localStorage.setItem(keyFor(user), value);
    else localStorage.removeItem(keyFor(user));
    window.dispatchEvent(new CustomEvent("techzone-profile-picture-updated", { detail: { key: keyFor(user) } }));
  } catch {
    // Ignore storage failures; the UI still remains usable.
  }
}

export function removeProfileImage(user) {
  setProfileImage(user, "");
}
