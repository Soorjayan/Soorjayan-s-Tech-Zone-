const prefix = "techzone_entity_image_";

function keysFor(type, entity) {
  const values = [entity?._id, entity?.id, entity?.email, entity?.name].filter(Boolean).map(String);
  return [...new Set(values)].map(value => `${prefix}${type}_${value}`);
}

export function getEntityImage(type, entity) {
  try {
    for (const key of keysFor(type, entity)) {
      const value = localStorage.getItem(key);
      if (value) return value;
    }
  } catch {}
  return "";
}

export function setEntityImage(type, entity, value) {
  const keys = keysFor(type, entity);
  if (!keys.length) return;
  try {
    if (value) keys.forEach(key => localStorage.setItem(key, value));
    else keys.forEach(key => localStorage.removeItem(key));
    window.dispatchEvent(new CustomEvent("techzone-entity-image-updated", { detail: { type, id: entity?._id || entity?.email || entity?.name } }));
  } catch {}
}

export function removeEntityImage(type, entity) {
  setEntityImage(type, entity, "");
}
