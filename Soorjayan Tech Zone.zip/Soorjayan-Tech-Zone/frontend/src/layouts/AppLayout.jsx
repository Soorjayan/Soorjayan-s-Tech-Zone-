import { useEffect, useState } from "react";
import { NavLink, Outlet, useLocation } from "react-router-dom";
import { Boxes, ClipboardList, Factory, LayoutDashboard, LogOut, Menu, Package, ShoppingCart, Tags, Truck, UserCog, UserRound, Users, X, ChevronRight, MoreVertical, ZoomIn, Sun, Moon } from "lucide-react";
import { useAuth } from "../context/AuthContext";
import techLogo from "../assets/tech-zone-s-logo.png";
import { getProfileImage } from "../utils/profileImage";
import { getTheme, setTheme } from "../utils/theme";

const nav = [
  { to:"/dashboard", label:"Dashboard", icon:LayoutDashboard, roles:["admin","staff","delivery","customer"] },
  { to:"/products", label:"Products", icon:Package, roles:["admin","staff","customer"] },
  { to:"/categories", label:"Categories", icon:Tags, roles:["admin"] },
  { to:"/brands", label:"Brands", icon:Tags, roles:["admin"] },
  { to:"/inventory", label:"Inventory", icon:Boxes, roles:["admin","staff"], permission:"inventoryManagement" },
  { to:"/suppliers", label:"Suppliers", icon:Factory, roles:["admin"] },
  { to:"/customers", label:"Customers", icon:Users, roles:["admin","staff"], permission:"customerManagement" },
  { to:"/staff", label:"Staff", icon:UserCog, roles:["admin"] },
  { to:"/delivery-staff", label:"Delivery Staff", icon:Truck, roles:["admin"] },
  { to:"/orders", label:"Orders", icon:ClipboardList, roles:["admin","staff","delivery"], permission:"orderProcessing", allowRoles:["delivery"] },
  { to:"/my-orders", label:"My Orders", icon:ClipboardList, roles:["customer"] },
  { to:"/cart", label:"Cart", icon:ShoppingCart, roles:["customer"] },
  { to:"/profile", label:"Profile", icon:UserRound, roles:["admin","staff","delivery","customer"] }
];

const roleNames = { admin:"Admin", staff:"Staff", delivery:"Delivery", customer:"Customer" };

function Avatar({ user, className="" }) {
  const [image, setImage] = useState(() => getProfileImage(user));
  useEffect(() => {
    const refresh = () => setImage(getProfileImage(user));
    window.addEventListener("techzone-profile-picture-updated", refresh);
    window.addEventListener("storage", refresh);
    return () => {
      window.removeEventListener("techzone-profile-picture-updated", refresh);
      window.removeEventListener("storage", refresh);
    };
  }, [user]);
  return image
    ? <img className={`avatar-image ${className}`} src={image} alt={`${user?.name || "User"} profile`} />
    : <div className={`avatar avatar-blue ${className}`}>{user?.name?.charAt(0)?.toUpperCase()||"U"}</div>;
}

export default function AppLayout(){
 const {user,signOut}=useAuth();
 const [open,setOpen]=useState(false);
 const [zoom,setZoom]=useState(()=>Number(localStorage.getItem("techzone_zoom")||100));
 const [zoomOpen,setZoomOpen]=useState(false);
 const [theme,setThemeState]=useState(()=>getTheme());
 const location=useLocation();
 useEffect(()=>{setThemeState(setTheme(getTheme()));},[]);
 const items=nav.filter(item=>{
   if(!item.roles.includes(user?.role)) return false;
   if(!item.permission) return true;
   if(item.allowRoles?.includes(user?.role)) return true;
   return user?.role==="admin" || !!user?.permissions?.[item.permission];
 });
 const current=items.find((item)=>location.pathname===item.to || location.pathname.startsWith(`${item.to}/`));
 const changeZoom=(value)=>{
   const next=Number(value);
   setZoom(next);
   localStorage.setItem("techzone_zoom",String(next));
   setZoomOpen(false);
 };
 return <div className="app-shell">
  <aside className={`sidebar ${open?"sidebar-open":""}`}>
   <div className="brand">
    <img className="brand-logo-image" src={techLogo} alt="Soorjayan's Tech Zone"/>
    <div><strong>Tech Zone</strong><span>Electronics Store</span></div>
    <button className="mobile-close" onClick={()=>setOpen(false)}><X size={20}/></button>
   </div>
   <div className="user-mini"><Avatar user={user}/><div><strong>{user?.name}</strong><span>{roleNames[user?.role] || user?.role}</span></div></div>
   <div className="sidebar-label">Workspace</div>
   <nav>{items.map(({to,label,icon:Icon})=><NavLink key={to} to={to} onClick={()=>setOpen(false)} className={({isActive})=>isActive?"nav-link active":"nav-link"}><span className="nav-icon"><Icon size={17}/></span><span>{label}</span>{location.pathname===to && <ChevronRight size={15} className="nav-arrow"/>}</NavLink>)}</nav>
   <div className="sidebar-footer"><button className="logout-btn" onClick={signOut}><LogOut size={18}/> Sign out</button><small>Secure account access</small></div>
  </aside>
  <div className="main-area">
   <header className="topbar">
    <button className="mobile-menu" onClick={()=>setOpen(true)}><Menu/></button>
    <div className="topbar-breadcrumb"><strong>Soorjayan's Tech Zone</strong><span>/</span><span>{current?.label || "Workspace"}</span></div>
    <div className="topbar-right">
    <div className="topbar-user"><Avatar user={user} className="topbar-avatar-image"/><div><strong>{user?.name}</strong><small>{roleNames[user?.role] || user?.role}</small></div></div>
    <div className="topbar-divider" aria-hidden="true"></div>
    <button type="button" className="theme-toggle" aria-label={`Switch to ${theme === "dark" ? "light" : "dark"} mode`} onClick={()=>setThemeState(setTheme(theme === "dark" ? "light" : "dark"))}>
      {theme === "dark" ? <Sun size={18}/> : <Moon size={18}/>}
    </button>
    <div className="zoom-control">
      <button type="button" className="topbar-more" aria-label="Display zoom options" aria-expanded={zoomOpen} onClick={()=>setZoomOpen(v=>!v)}>
        <MoreVertical size={20}/>
      </button>
      {zoomOpen && <div className="zoom-menu">
        <div className="zoom-menu-title"><ZoomIn size={14}/> Display zoom <strong>{zoom}%</strong></div>
        <input
          className="zoom-range"
          type="range"
          min="25"
          max="200"
          step="1"
          value={zoom}
          onChange={e=>changeZoom(e.target.value)}
          aria-label="Display zoom percentage"
        />
        <div className="zoom-range-labels"><span>25%</span><span>200%</span></div>
      </div>}
    </div>
   </div>
   </header>
   <main className="content" style={{zoom:`${zoom}%`}}><Outlet/></main>
   <footer className="app-copyright">© 2026 Soorjayan's Tech Zone · All rights reserved. · <span>Privacy Policy</span></footer>
  </div>
 </div>;
}
