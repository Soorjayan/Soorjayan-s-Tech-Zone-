import { Navigate, Route, Routes } from "react-router-dom";
import { useAuth } from "./context/AuthContext";
import ProtectedRoute from "./routes/ProtectedRoute";
import RoleRoute from "./routes/RoleRoute";
import AppLayout from "./layouts/AppLayout";

import Login from "./pages/auth/Login";
import Register from "./pages/auth/Register";
import ForgotPassword from "./pages/auth/ForgotPassword";
import Dashboard from "./pages/Dashboard";
import Products from "./pages/products/Products";
import ProductDetails from "./pages/products/ProductDetails";
import Categories from "./pages/catalog/Categories";
import Brands from "./pages/catalog/Brands";
import Inventory from "./pages/inventory/Inventory";
import Suppliers from "./pages/suppliers/Suppliers";
import Customers from "./pages/customers/Customers";
import Staff from "./pages/staff/Staff";
import DeliveryStaff from "./pages/delivery/DeliveryStaff";
import Orders from "./pages/orders/Orders";
import MyOrders from "./pages/orders/MyOrders";
import Cart from "./pages/customer/Cart";
import Checkout from "./pages/customer/Checkout";
import Profile from "./pages/Profile";
import NotFound from "./pages/NotFound";

function HomeRedirect(){const {user}=useAuth();return user?<Navigate to="/dashboard" replace/>:<Navigate to="/login" replace/>;}

export default function App(){
 return <Routes>
  <Route path="/" element={<HomeRedirect/>}/>
  <Route path="/login" element={<Login/>}/>
  <Route path="/register" element={<Register/>}/>
  <Route path="/forgot-password" element={<ForgotPassword/>}/>
  <Route element={<ProtectedRoute/>}>
   <Route element={<AppLayout/>}>
    <Route path="/dashboard" element={<Dashboard/>}/>
    <Route path="/products" element={<Products/>}/>
    <Route path="/products/:id" element={<ProductsAndDetails/>}/>
    <Route path="/categories" element={<RoleRoute roles={["admin"]}><Categories/></RoleRoute>}/>
    <Route path="/brands" element={<RoleRoute roles={["admin"]}><Brands/></RoleRoute>}/>
    <Route path="/inventory" element={<RoleRoute roles={["admin","staff"]}><Inventory/></RoleRoute>}/>
    <Route path="/suppliers" element={<RoleRoute roles={["admin"]}><Suppliers/></RoleRoute>}/>
    <Route path="/customers" element={<RoleRoute roles={["admin","staff"]}><Customers/></RoleRoute>}/>
    <Route path="/staff" element={<RoleRoute roles={["admin"]}><Staff/></RoleRoute>}/>
    <Route path="/delivery-staff" element={<RoleRoute roles={["admin"]}><DeliveryStaff/></RoleRoute>}/>
    <Route path="/orders" element={<RoleRoute roles={["admin","staff","delivery"]}><Orders/></RoleRoute>}/>
    <Route path="/my-orders" element={<RoleRoute roles={["customer"]}><MyOrders/></RoleRoute>}/>
    <Route path="/cart" element={<RoleRoute roles={["customer"]}><Cart/></RoleRoute>}/>
    <Route path="/checkout" element={<RoleRoute roles={["customer"]}><Checkout/></RoleRoute>}/>
    <Route path="/profile" element={<Profile/>}/>
   </Route>
  </Route>
  <Route path="*" element={<NotFound/>}/>
 </Routes>;
}

function ProductsAndDetails(){
  return <ProductDetails/>;
}
