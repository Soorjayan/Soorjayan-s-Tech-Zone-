import { createContext, useContext, useMemo, useState } from "react";
import * as authService from "../services/authService";

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => {
    try { return JSON.parse(localStorage.getItem("techzone_user")) || null; }
    catch { return null; }
  });
  const [loading, setLoading] = useState(false);

  const signIn = async (credentials) => {
    setLoading(true);
    try {
      const response = await authService.login(credentials);
      const data = response.data;
      const loggedUser = data.user || data.data?.user;
      const token = data.token || data.data?.token;
      if (!token || !loggedUser) throw new Error(data.message || "Login response is incomplete");
      localStorage.setItem("techzone_token", token);
      localStorage.setItem("techzone_user", JSON.stringify(loggedUser));
      setUser(loggedUser);
      return data;
    } finally {
      setLoading(false);
    }
  };

  const updateUser = (updates) => {
    setUser((current) => {
      if (!current) return current;
      const nextUser = { ...current, ...updates };
      localStorage.setItem("techzone_user", JSON.stringify(nextUser));
      return nextUser;
    });
  };

  const signOut = () => {
    localStorage.removeItem("techzone_token");
    localStorage.removeItem("techzone_user");
    setUser(null);
  };

  const value = useMemo(() => ({ user, loading, signIn, signOut, updateUser }), [user, loading]);
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export const useAuth = () => useContext(AuthContext);