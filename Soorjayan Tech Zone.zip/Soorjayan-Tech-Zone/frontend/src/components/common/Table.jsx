export default function Table({ columns, data, empty = "No records found." }) {
  if (!data?.length) return <div className="table-wrap"><div className="table-empty">{empty}</div></div>;
  return (
    <div className="table-wrap">
      <table><thead><tr>{columns.map((c) => <th key={c.key}>{c.label}</th>)}</tr></thead>
      <tbody>{data.map((row, i) => <tr key={row._id || row.id || i}>{columns.map((c) => <td key={c.key}>{c.render ? c.render(row) : row[c.key] ?? "—"}</td>)}</tr>)}</tbody>
      </table>
    </div>
  );
}