export default function StatCard({ icon, label, value, hint }) {
  return (
    <div className="stat-card">
      <div className="stat-icon">{icon}</div>
      <div><span className="stat-label">{label}</span><strong>{value ?? "—"}</strong>{hint && <small>{hint}</small>}</div>
    </div>
  );
}