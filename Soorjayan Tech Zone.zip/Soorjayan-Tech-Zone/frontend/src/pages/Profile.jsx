import { useEffect,useRef,useState } from "react";
import { Camera, ImagePlus, Trash2, Eye, EyeOff } from "lucide-react";
import { getProfile,updateProfile } from "../services/profileService";
import { changePassword } from "../services/authService";
import { useAuth } from "../context/AuthContext";
import { getProfileImage, setProfileImage, removeProfileImage } from "../utils/profileImage";
import PageHeader from "../components/common/PageHeader";
import Alert from "../components/common/Alert";
import Spinner from "../components/common/Spinner";

export default function Profile(){
 const {user,updateUser}=useAuth();
 const [form,setForm]=useState({name:user?.name||"",phone:user?.phone||"",address:user?.address||""});
 const [pass,setPass]=useState({currentPassword:"",newPassword:""});
 const [msg,setMsg]=useState("");const [error,setError]=useState("");const [loading,setLoading]=useState(true);
 const [profileImage,setProfileImageState]=useState(()=>getProfileImage(user));
 const [imageError,setImageError]=useState("");
 const [showCurrent,setShowCurrent]=useState(false);
 const [showNew,setShowNew]=useState(false);
 const [editing,setEditing]=useState(false);
 const fileRef=useRef(null);

 useEffect(()=>{getProfile().then(r=>{
   const d=r.data?.data||r.data;
   const next={name:d.name||"",phone:d.phone||"",address:d.address||""};
   setForm(next);
   updateUser(next);
 }).catch(()=>{}).finally(()=>setLoading(false))},[]);
 const startEditing=()=>{setMsg("");setError("");setEditing(true)};
 const saveProfile=async()=>{
   try{
     const response=await updateProfile(form);
     const body=response.data?.data||response.data||{};
     const savedUser=body.user||body.profile||body;
     const next={name:savedUser.name||form.name,phone:savedUser.phone??form.phone,address:savedUser.address??form.address};
     setForm(next); updateUser(next); setMsg("Profile updated successfully."); setError(""); setEditing(false);
   }catch(e){setError(e.response?.data?.message||"Update failed")}
 };
 const handleProfileAction=()=>{if(editing){saveProfile();}else{startEditing();}};
 const password=async(e)=>{e.preventDefault();try{await changePassword(pass);setMsg("Password changed successfully.");setPass({currentPassword:"",newPassword:""});setError("")}catch(e){setError(e.response?.data?.message||"Password change failed")}};
 const chooseImage=(e)=>{
   const file=e.target.files?.[0]; if(!file) return;
   setImageError("");
   if(!file.type.startsWith("image/")) return setImageError("Please choose an image file.");
   if(file.size>2*1024*1024) return setImageError("Profile picture must be 2 MB or smaller.");
   const reader=new FileReader();
   reader.onload=()=>{ const value=String(reader.result); setProfileImage(user,value); setProfileImageState(value); setMsg("Profile picture updated successfully."); setError(""); };
   reader.readAsDataURL(file);
 };
 const removeImage=()=>{removeProfileImage(user);setProfileImageState("");setMsg("Profile picture removed.");setError("")};
 if(loading)return <Spinner/>;
 return <div className="profile-page">
  <PageHeader title="My profile" subtitle="Manage your account information, profile picture and security."/>
  <Alert>{error || imageError}</Alert><Alert type="success">{msg}</Alert>
  <div className="profile-picture-card card">
    <div className="profile-picture-preview">
      {profileImage ? <img src={profileImage} alt="Profile" /> : <span>{user?.name?.charAt(0)?.toUpperCase()||"U"}</span>}
    </div>
    <div className="profile-picture-copy">
      <span className="eyebrow">ACCOUNT PERSONALIZATION</span>
      <h2>Profile picture</h2>
      <p>Choose a clear photo to personalize your Tech Zone workspace. This picture is used across your sidebar and account header.</p>
      <div className="profile-picture-actions">
        <button type="button" className="btn btn-primary" onClick={()=>fileRef.current?.click()}><Camera size={16}/> Add picture</button>
        {profileImage && <button type="button" className="btn btn-secondary" onClick={removeImage}><Trash2 size={16}/> Remove</button>}
        <input ref={fileRef} type="file" accept="image/png,image/jpeg,image/webp" hidden onChange={chooseImage}/>
      </div>
      <small>PNG, JPG or WEBP · Maximum 2 MB</small>
    </div>
  </div>
  <div className="profile-grid">
   <form className="card form-grid" onSubmit={e=>e.preventDefault()}><h2>Profile information</h2><label>Name<input disabled={!editing} value={form.name} onChange={e=>setForm({...form,name:e.target.value})}/></label><label>Email<input disabled value={user?.email||""}/></label><label>Phone<input disabled={!editing} value={form.phone} onChange={e=>setForm({...form,phone:e.target.value})}/></label><label>Address<textarea disabled={!editing} rows="4" value={form.address} onChange={e=>setForm({...form,address:e.target.value})}/></label><button type="button" onClick={handleProfileAction} className="btn btn-primary">{editing?"Save profile":"Edit profile"}</button></form>
   <form className="card form-grid" onSubmit={password}><h2>Change password</h2><label>Current password<div className="password-field"><input required type={showCurrent?"text":"password"} value={pass.currentPassword} onChange={e=>setPass({...pass,currentPassword:e.target.value})}/><button type="button" onClick={()=>setShowCurrent(v=>!v)} aria-label="Toggle current password">{showCurrent?<EyeOff size={17}/>:<Eye size={17}/>}</button></div></label><label>New password<div className="password-field"><input required minLength="6" type={showNew?"text":"password"} value={pass.newPassword} onChange={e=>setPass({...pass,newPassword:e.target.value})}/><button type="button" onClick={()=>setShowNew(v=>!v)} aria-label="Toggle new password">{showNew?<EyeOff size={17}/>:<Eye size={17}/>}</button></div></label><button className="btn btn-primary">Change password</button></form>
  </div>
 </div>;
}
