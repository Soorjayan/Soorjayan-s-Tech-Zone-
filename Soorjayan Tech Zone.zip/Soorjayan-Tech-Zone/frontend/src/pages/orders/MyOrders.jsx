import { useEffect,useState } from "react";
import { getMyOrders,cancelOrder } from "../../services/orderService";
import PageHeader from "../../components/common/PageHeader";
import Spinner from "../../components/common/Spinner";
import EmptyState from "../../components/common/EmptyState";
import Alert from "../../components/common/Alert";

export default function MyOrders(){
  const [items,setItems]=useState([]),[loading,setLoading]=useState(true),[error,setError]=useState("");
  const load=async()=>{try{const r=await getMyOrders();const d=r.data?.data||r.data;setItems(d.orders||d||[])}catch(e){setError(e.response?.data?.message||"Unable to load orders")}finally{setLoading(false)}};
  useEffect(()=>{load()},[]);
  const cancel=async(id)=>{try{await cancelOrder(id);load()}catch(e){setError(e.response?.data?.message||"Unable to cancel order")}};
  if(loading)return <div className="center-page"><Spinner/></div>;
  return <><PageHeader title="My orders" subtitle="Track your purchases and order status."/><Alert>{error}</Alert>{!items.length?<EmptyState title="No orders yet"/>:<div className="card"><div className="order-list">{items.map(o=><div className="order-row" key={o._id}><div><strong>#{String(o._id).slice(-8)}</strong><span>{new Date(o.createdAt).toLocaleString()}</span></div><div><span className={`status status-${String(o.orderStatus).toLowerCase()}`}>{o.orderStatus}</span><small>{o.paymentStatus}</small></div><strong>Rs. {Number(o.totalAmount||0).toLocaleString()}</strong>{["PLACED","CONFIRMED"].includes(o.orderStatus)&&<button className="btn btn-danger btn-sm" onClick={()=>cancel(o._id)}>Cancel</button>}</div>)}</div></div>}</>;
}