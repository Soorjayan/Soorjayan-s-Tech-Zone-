import { useEffect, useState } from "react";
import {
  getOrders,
  updateOrderStatus,
  assignDelivery
} from "../../services/orderService";
import { getDeliveryStaff } from "../../services/adminService";
import { getMyDeliveryOrders } from "../../services/deliveryService";
import { useAuth } from "../../context/AuthContext";
import PageHeader from "../../components/common/PageHeader";
import Spinner from "../../components/common/Spinner";
import Table from "../../components/common/Table";
import Alert from "../../components/common/Alert";
import { updatePaymentStatus } from "../../services/paymentService";

const statuses = [
  "PLACED",
  "CONFIRMED",
  "PROCESSING",
  "SHIPPED",
  "OUT_FOR_DELIVERY",
  "DELIVERED",
  "CANCELLED"
];

const paymentStatuses = ["PENDING", "PAID", "FAILED"];

export default function Orders() {
  const { user } = useAuth();
  const isDelivery = user?.role === "delivery";

  const [items, setItems] = useState([]);
  const [deliveryStaff, setDeliveryStaff] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [status, setStatus] = useState("");
  const [search, setSearch] = useState("");

  const load = async () => {
    setLoading(true);
    setError("");

    try {
      if (isDelivery) {
        const response = await getMyDeliveryOrders();
        const data = response.data?.data || response.data || [];
        setItems(Array.isArray(data) ? data : data.orders || []);
        return;
      }

      const response = await getOrders({
        ...(status ? { status } : {}),
        ...(search ? { search } : {})
      });

      const data = response.data?.data || response.data || [];
      setItems(Array.isArray(data) ? data : data.orders || []);

      // Only Admin can assign/reassign delivery staff.
      if (user?.role === "admin") {
        const staffResponse = await getDeliveryStaff({
          status: "active",
          limit: 100
        });

        const body = staffResponse.data?.data ?? staffResponse.data ?? {};

        // Backend returns { success, data: [...] }.
        // Support both array and wrapped response shapes.
        const staffList = Array.isArray(body)
          ? body
          : body.deliveryStaff || body.data || body.staff || [];

        setDeliveryStaff(staffList);
      }
    } catch (e) {
      setError(
        e.response?.data?.message || "Unable to load orders"
      );
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, [status, isDelivery]);

  const changeStatus = async (id, newStatus) => {
    try {
      await updateOrderStatus(id, { orderStatus: newStatus });
      await load();
    } catch (e) {
      setError(
        e.response?.data?.message || "Unable to update order"
      );
    }
  };

  const changePayment = async (id, newStatus) => {
    try {
      await updatePaymentStatus(id, newStatus);
      await load();
    } catch (e) {
      setError(
        e.response?.data?.message || "Unable to update payment"
      );
    }
  };

  const assign = async (id, staffId) => {
    if (!staffId) return;

    try {
      await assignDelivery(id, {
        deliveryStaffId: staffId
      });

      await load();
    } catch (e) {
      setError(
        e.response?.data?.message ||
          "Unable to assign delivery staff"
      );
    }
  };

  const columns = [
    {
      key: "_id",
      label: "Order",
      render: (row) => `#${String(row._id).slice(-8)}`
    },
    {
      key: "customer",
      label: "Customer",
      render: (row) =>
        row.customer?.name ||
        row.user?.name ||
        row.name ||
        "—"
    },
    {
      key: "totalAmount",
      label: "Total",
      render: (row) =>
        `Rs. ${Number(row.totalAmount || 0).toLocaleString()}`
    },
    {
      key: "paymentStatus",
      label: "Payment",
      render: (row) =>
        user?.role === "admin" || user?.role === "staff" ? (
          <select
            value={row.paymentStatus || "PENDING"}
            onChange={(e) =>
              changePayment(row._id, e.target.value)
            }
          >
            {paymentStatuses.map((value) => (
              <option key={value}>{value}</option>
            ))}
          </select>
        ) : (
          <span className="status">{row.paymentStatus}</span>
        )
    },
    {
      key: "orderStatus",
      label: "Status",
      render: (row) => (
        <select
          value={row.orderStatus}
          onChange={(e) =>
            changeStatus(row._id, e.target.value)
          }
        >
          {statuses.map((value) => (
            <option key={value}>{value}</option>
          ))}
        </select>
      )
    },
    ...(user?.role === "admin"
      ? [
          {
            key: "delivery",
            label: "Delivery Staff",
            render: (row) => (
              <select
                value={
                  row.assignedDeliveryStaff?._id ||
                  row.assignedDeliveryStaff ||
                  ""
                }
                onChange={(e) =>
                  assign(row._id, e.target.value)
                }
              >
                <option value="" disabled>
                  {row.assignedDeliveryStaff
                    ? "Assigned"
                    : "Select staff"}
                </option>

                {deliveryStaff.map((staff) => (
                  <option key={staff._id} value={staff._id}>
                    {staff.name}
                  </option>
                ))}
              </select>
            )
          }
        ]
      : []),
    {
      key: "createdAt",
      label: "Date",
      render: (row) =>
        new Date(row.createdAt).toLocaleDateString()
    }
  ];

  return (
    <>
      <PageHeader
        title={isDelivery ? "My Deliveries" : "Orders"}
        subtitle={
          isDelivery
            ? "View your assigned deliveries and update delivery status."
            : "Process, track, assign and update customer orders."
        }
      />

      {!isDelivery && (
        <div className="toolbar">
          <div className="search-box">
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              onKeyDown={(e) =>
                e.key === "Enter" && load()
              }
              placeholder="Search orders..."
            />
          </div>

          <select
            value={status}
            onChange={(e) => setStatus(e.target.value)}
          >
            <option value="">All statuses</option>
            {statuses.map((value) => (
              <option key={value}>{value}</option>
            ))}
          </select>

          <button
            className="btn btn-secondary"
            onClick={load}
          >
            Search
          </button>
        </div>
      )}

      <Alert>{error}</Alert>

      {loading ? (
        <div className="center-page">
          <Spinner />
        </div>
      ) : (
        <Table
          columns={columns}
          data={items}
          empty={
            isDelivery
              ? "No deliveries assigned."
              : "No orders found."
          }
        />
      )}
    </>
  );
}
