import { useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { ArrowLeft, Pencil, ShoppingCart, Trash2 } from "lucide-react";
import { getProduct, updateProduct, deleteProduct } from "../../services/productService";
import { getCategories, getBrands } from "../../services/catalogService";
import { getSuppliers } from "../../services/adminService";
import { useAuth } from "../../context/AuthContext";
import { addToCart } from "../../services/cartService";
import Spinner from "../../components/common/Spinner";
import Alert from "../../components/common/Alert";
import Modal from "../../components/common/Modal";

const emptySpecs = { processor:"", ram:"", storage:"", display:"", graphics:"" };

function ProductDetailImage({ src, name }) {
  const [failed, setFailed] = useState(false);
  useEffect(() => setFailed(false), [src]);
  return <div className="details-image">{src && !failed ? <img src={src} alt={name} onError={()=>setFailed(true)}/> :
    <div className="image-placeholder large"><ShoppingCart size={70}/><span>No image available</span></div>}</div>;
}

export default function ProductDetails() {
  const { id } = useParams();
  const nav = useNavigate();
  const { user } = useAuth();
  const canManage = ["admin","staff"].includes(user?.role);
  const canDelete = user?.role === "admin";
  const [p,setP] = useState(null), [qty,setQty]=useState(1), [msg,setMsg]=useState(""), [error,setError]=useState("");
  const [modal,setModal]=useState(false), [catalog,setCatalog]=useState({categories:[],brands:[],suppliers:[]}), [form,setForm]=useState(null), [saving,setSaving]=useState(false);

  const load = async () => {
    try { const r=await getProduct(id); setP(r.data?.data||r.data); }
    catch(e){ setError(e.response?.data?.message||"Product not found"); }
  };
  useEffect(()=>{load()},[id]);

  const edit = async () => {
    const [c,b,s] = await Promise.allSettled([getCategories({status:"active"}),getBrands({status:"active"}),getSuppliers({status:"active",limit:100})]);
    const list = (r, keys) => { const d=r?.value?.data?.data??r?.value?.data??{}; for(const k of keys) if(Array.isArray(d[k])) return d[k]; return Array.isArray(d)?d:[]; };
    setCatalog({categories:list(c,["categories","items"]),brands:list(b,["brands","items"]),suppliers:list(s,["suppliers","items"])});
    setForm({...p, supplier:p.supplier?._id||p.supplier||"", specifications:{...emptySpecs,...(p.specifications||{})}});
    setModal(true);
  };

  const save = async e => {
    e.preventDefault(); setSaving(true); setError("");
    try {
      const payload={name:form.name,description:form.description,price:Number(form.price),discount:Number(form.discount||0),stock:Number(form.stock),category:form.category,brand:form.brand,image:form.image||"",warranty:form.warranty||"",specifications:form.specifications};
      if(form.supplier) payload.supplier=form.supplier;
      await updateProduct(id,payload); setModal(false); await load(); setMsg("Product updated successfully.");
    } catch(e){setError(e.response?.data?.message||"Unable to update product");} finally{setSaving(false);}
  };

  const remove = async () => {
    if(!confirm(`Delete "${p.name}"?`)) return;
    try { await deleteProduct(id); nav("/products"); }
    catch(e){setError(e.response?.data?.message||"Unable to delete product");}
  };

  if(!p&&!error) return <div className="center-page"><Spinner/></div>;
  if(error&&!p) return <Alert>{error}</Alert>;
  const canCart=user?.role==="customer";
  const cart=async()=>{try{await addToCart({productId:id,quantity:Number(qty)});setMsg("Product added to cart.");}catch(e){setError(e.response?.data?.message||"Unable to add to cart");}};
  const specs=p.specifications||{};

  return <div>
    <Link to="/products" className="back-link"><ArrowLeft size={16}/> Back to products</Link>
    <Alert>{error}</Alert><Alert type="success">{msg}</Alert>
    <div className="details-card">
      <ProductDetailImage src={p.image} name={p.name}/>
      <div className="details-content">
        <span className="product-category">{p.category||"Electronics"}</span>
        <h1>{p.name}</h1>
        <p>{p.description}</p>
        <div className="price">Rs. {Number(p.price||0).toLocaleString()}</div>
        {Number(p.discount)>0 && <span className="discount-label">{p.discount}% discount</span>}
        <p><strong>Brand:</strong> {p.brand||"—"} &nbsp; <strong>Stock:</strong> {p.stock??0}</p>
        {p.warranty && <p><strong>Warranty:</strong> {p.warranty}</p>}
        {p.supplier && <p><strong>Supplier:</strong> {p.supplier.name || p.supplier.company || "Assigned supplier"}</p>}
        {Object.values(specs).some(Boolean) && <div className="details-specs"><h3>Specifications</h3>{Object.entries(specs).filter(([,v])=>v).map(([k,v])=><div key={k}><span>{k}</span><strong>{v}</strong></div>)}</div>}
        {canCart && <div className="buy-row"><input type="number" min="1" max={p.stock||1} value={qty} onChange={e=>setQty(e.target.value)}/><button className="btn btn-primary" disabled={!p.stock} onClick={cart}><ShoppingCart size={17}/> Add to cart</button></div>}
        {canManage && <div className="details-admin-actions"><button className="btn btn-secondary" onClick={edit}><Pencil size={16}/> Edit product</button>{canDelete&&<button className="btn btn-danger" onClick={remove}><Trash2 size={16}/> Delete</button>}</div>}
      </div>
    </div>

    {modal && form && <Modal title="Edit product" onClose={()=>setModal(false)}>
      <form className="form-grid two-col" onSubmit={save}>
        <label>Product name<input required value={form.name||""} onChange={e=>setForm({...form,name:e.target.value})}/></label>
        <label>Price<input required type="number" min="0" value={form.price||""} onChange={e=>setForm({...form,price:e.target.value})}/></label>
        <label>Stock<input required type="number" min="0" value={form.stock??0} onChange={e=>setForm({...form,stock:e.target.value})}/></label>
        <label>Discount (%)<input type="number" min="0" max="100" value={form.discount??0} onChange={e=>setForm({...form,discount:e.target.value})}/></label>
        <label>Category<select required value={form.category||""} onChange={e=>setForm({...form,category:e.target.value})}>{catalog.categories.map(x=><option key={x._id} value={x.name}>{x.name}</option>)}</select></label>
        <label>Brand<select required value={form.brand||""} onChange={e=>setForm({...form,brand:e.target.value})}>{catalog.brands.map(x=><option key={x._id} value={x.name}>{x.name}</option>)}</select></label>
        <label>Supplier<select value={form.supplier||""} onChange={e=>setForm({...form,supplier:e.target.value})}><option value="">No supplier</option>{catalog.suppliers.map(x=><option key={x._id} value={x._id}>{x.name}</option>)}</select></label>
        <label>Image URL<input type="url" value={form.image||""} onChange={e=>setForm({...form,image:e.target.value})}/></label>
        <label>Warranty<input value={form.warranty||""} onChange={e=>setForm({...form,warranty:e.target.value})}/></label>
        <label className="full">Description<textarea required value={form.description||""} onChange={e=>setForm({...form,description:e.target.value})}/></label>
        <div className="spec-box full"><strong>Specifications</strong><div className="form-grid two-col">{Object.keys(emptySpecs).map(k=><label key={k}>{k}<input value={form.specifications?.[k]||""} onChange={e=>setForm({...form,specifications:{...form.specifications,[k]:e.target.value}})}/></label>)}</div></div>
        <div className="modal-actions full"><button type="button" className="btn btn-secondary" onClick={()=>setModal(false)}>Cancel</button><button className="btn btn-primary" disabled={saving}>{saving?"Saving...":"Save changes"}</button></div>
      </form>
    </Modal>}
  </div>;
}
