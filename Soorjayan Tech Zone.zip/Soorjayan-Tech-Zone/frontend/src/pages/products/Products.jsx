import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Plus, Search, ShoppingCart, SlidersHorizontal, Pencil, Trash2 } from "lucide-react";
import { getProducts, createProduct, updateProduct, deleteProduct } from "../../services/productService";
import { getCategories, getBrands } from "../../services/catalogService";
import { getSuppliers } from "../../services/adminService";
import { useAuth } from "../../context/AuthContext";
import PageHeader from "../../components/common/PageHeader";
import Spinner from "../../components/common/Spinner";
import Alert from "../../components/common/Alert";
import Modal from "../../components/common/Modal";
import EmptyState from "../../components/common/EmptyState";

const blank = {
  name: "", description: "", price: "", discount: 0, stock: "",
  category: "", brand: "", supplier: "", image: "",
  warranty: "", specifications: { processor: "", ram: "", storage: "", display: "", graphics: "" }
};

const extractList = (response, keys) => {
  const data = response?.data?.data ?? response?.data ?? {};
  for (const key of keys) if (Array.isArray(data?.[key])) return data[key];
  return Array.isArray(data) ? data : [];
};

function ProductImage({ src, name }) {
  const [failed, setFailed] = useState(false);
  useEffect(() => setFailed(false), [src]);
  return (
    <div className="product-image">
      {src && !failed ? (
        <img src={src} alt={name} loading="lazy" onError={() => setFailed(true)} />
      ) : (
        <div className="image-placeholder" aria-label="Product image unavailable">
          <ShoppingCart size={42} /><span>No image</span>
        </div>
      )}
    </div>
  );
}

export default function Products() {
  const { user } = useAuth();
  const canManage = ["admin", "staff"].includes(user?.role);
  const canDelete = user?.role === "admin";

  const [items, setItems] = useState([]);
  const [categories, setCategories] = useState([]);
  const [brands, setBrands] = useState([]);
  const [suppliers, setSuppliers] = useState([]);
  const [pagination, setPagination] = useState({ currentPage: 1, totalPages: 1, totalProducts: 0 });
  const [filters, setFilters] = useState({ search: "", category: "", brand: "", minPrice: "", maxPrice: "", sort: "newest", page: 1 });
  const [loading, setLoading] = useState(true);
  const [catalogLoading, setCatalogLoading] = useState(false);
  const [error, setError] = useState("");
  const [modal, setModal] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(blank);
  const [saving, setSaving] = useState(false);

  const load = async (next = filters) => {
    setLoading(true);
    setError("");
    try {
      const params = {
        page: next.page || 1,
        limit: 12,
        sort: next.sort || "newest"
      };
      if (next.search.trim()) params.search = next.search.trim();
      if (next.category) params.category = next.category;
      if (next.brand) params.brand = next.brand;
      if (next.minPrice !== "") params.minPrice = Number(next.minPrice);
      if (next.maxPrice !== "") params.maxPrice = Number(next.maxPrice);

      const response = await getProducts(params);
      const data = response?.data?.data ?? response?.data ?? {};
      setItems(data.products || data.items || (Array.isArray(data) ? data : []));
      setPagination(data.pagination || { currentPage: 1, totalPages: 1, totalProducts: 0 });
    } catch (e) {
      setError(e.response?.data?.message || "Unable to load products");
    } finally {
      setLoading(false);
    }
  };

  const loadCatalogOptions = async () => {
    setCatalogLoading(true);
    try {
      const [c, b, s] = await Promise.allSettled([
        getCategories({ status: "active", limit: 100 }),
        getBrands({ status: "active", limit: 100 }),
        getSuppliers({ status: "active", limit: 100 })
      ]);
      if (c.status === "fulfilled") setCategories(extractList(c.value, ["categories", "items"]));
      if (b.status === "fulfilled") setBrands(extractList(b.value, ["brands", "items"]));
      if (s.status === "fulfilled") setSuppliers(extractList(s.value, ["suppliers", "items"]));
    } finally {
      setCatalogLoading(false);
    }
  };

  useEffect(() => { load(); loadCatalogOptions(); }, []);

  const openCreate = async () => {
    setEditing(null);
    setForm(blank);
    setError("");
    setModal(true);
    await loadCatalogOptions();
  };

  const openEdit = async (product) => {
    setEditing(product);
    setForm({
      ...blank,
      ...product,
      supplier: product.supplier?._id || product.supplier || "",
      specifications: { ...blank.specifications, ...(product.specifications || {}) }
    });
    setError("");
    setModal(true);
    await loadCatalogOptions();
  };

  const closeModal = () => {
    setModal(false);
    setEditing(null);
    setForm(blank);
  };

  const submit = async (e) => {
    e.preventDefault();
    setError("");

    if (!form.category || !form.brand) {
      setError("Category and brand are required.");
      return;
    }

    setSaving(true);
    try {
      const payload = {
        name: form.name.trim(),
        description: form.description.trim(),
        price: Number(form.price),
        discount: Number(form.discount || 0),
        stock: Number(form.stock),
        category: form.category,
        brand: form.brand,
        image: form.image.trim(),
        warranty: form.warranty.trim(),
        specifications: form.specifications
      };
      if (form.supplier) payload.supplier = form.supplier;

      if (editing) await updateProduct(editing._id, payload);
      else await createProduct(payload);

      closeModal();
      await load(filters);
    } catch (e) {
      setError(e.response?.data?.message || "Unable to save product");
    } finally {
      setSaving(false);
    }
  };

  const remove = async (product) => {
    if (!confirm(`Delete "${product.name}"?`)) return;
    try {
      await deleteProduct(product._id);
      await load(filters);
    } catch (e) {
      setError(e.response?.data?.message || "Unable to delete product");
    }
  };

  const setFilter = (key, value) => setFilters((f) => ({ ...f, [key]: value, page: 1 }));

  return (
    <>
      <PageHeader
        title="Products"
        subtitle="Browse, search and manage your electronics catalog."
        action={canManage && <button className="btn btn-primary" onClick={openCreate}><Plus size={17}/> Add product</button>}
      />

      <div className="product-filters card">
        <div className="filter-row">
          <div className="search-box">
            <Search size={17}/>
            <input value={filters.search} onChange={e => setFilter("search", e.target.value)}
              onKeyDown={e => e.key === "Enter" && load({ ...filters, page: 1 })} placeholder="Search by name, brand or category..." />
          </div>
          <select value={filters.category} onChange={e => setFilter("category", e.target.value)}>
            <option value="">All categories</option>
            {categories.map(c => <option key={c._id} value={c.name}>{c.name}</option>)}
          </select>
          <select value={filters.brand} onChange={e => setFilter("brand", e.target.value)}>
            <option value="">All brands</option>
            {brands.map(b => <option key={b._id} value={b.name}>{b.name}</option>)}
          </select>
          <select value={filters.sort} onChange={e => setFilter("sort", e.target.value)}>
            <option value="newest">Newest</option><option value="oldest">Oldest</option>
            <option value="name_asc">Name A–Z</option><option value="name_desc">Name Z–A</option>
            <option value="price_asc">Price low–high</option><option value="price_desc">Price high–low</option>
            <option value="stock_asc">Stock low–high</option><option value="stock_desc">Stock high–low</option>
          </select>
          <button className="btn btn-secondary" onClick={() => load({ ...filters, page: 1 })}><SlidersHorizontal size={16}/> Apply</button>
        </div>
      </div>

      <Alert>{error}</Alert>

      {loading ? <div className="center-page"><Spinner/></div> : !items.length ? <EmptyState title="No products found" text="Try changing your search or filters."/> :
        <>
          <div className="product-grid">
            {items.map(product => (
              <div className="product-card" key={product._id}>
                <Link to={`/products/${product._id}`}><ProductImage src={product.image} name={product.name}/></Link>
                <div className="product-info">
                  <span className="product-category">{typeof product.category === "object" ? product.category?.name : product.category || "Electronics"}</span>
                  <Link to={`/products/${product._id}`}><h3>{product.name}</h3></Link>
                  <p>{typeof product.brand === "object" ? product.brand?.name : product.brand || "—"}</p>
                  <strong>Rs. {Number(product.price || 0).toLocaleString()}</strong>
                  {Number(product.discount) > 0 && <small className="discount-label">{product.discount}% discount</small>}
                  <small>{product.stock ?? 0} in stock</small>
                  {canManage && <div className="product-actions">
                    <button className="btn btn-secondary btn-sm" onClick={() => openEdit(product)}><Pencil size={14}/> Edit</button>
                    {canDelete && <button className="btn btn-danger btn-sm" onClick={() => remove(product)}><Trash2 size={14}/> Delete</button>}
                  </div>}
                </div>
              </div>
            ))}
          </div>
          <div className="pagination">
            <button className="btn btn-secondary btn-sm" disabled={(pagination.currentPage || 1) <= 1}
              onClick={() => { const page = (pagination.currentPage || 1) - 1; const next = {...filters, page}; setFilters(next); load(next); }}>Previous</button>
            <span>Page {pagination.currentPage || 1} of {pagination.totalPages || 1} · {pagination.totalProducts ?? items.length} products</span>
            <button className="btn btn-secondary btn-sm" disabled={(pagination.currentPage || 1) >= (pagination.totalPages || 1)}
              onClick={() => { const page = (pagination.currentPage || 1) + 1; const next = {...filters, page}; setFilters(next); load(next); }}>Next</button>
          </div>
        </>
      }

      {modal && <Modal title={editing ? "Edit product" : "Add product"} onClose={closeModal}>
        <form className="form-grid two-col" onSubmit={submit}>
          <label>Product name<input required minLength="2" value={form.name} onChange={e=>setForm({...form,name:e.target.value})}/></label>
          <label>Price<input required type="number" min="0" value={form.price} onChange={e=>setForm({...form,price:e.target.value})}/></label>
          <label>Stock<input required type="number" min="0" value={form.stock} onChange={e=>setForm({...form,stock:e.target.value})}/></label>
          <label>Discount (%)<input type="number" min="0" max="100" value={form.discount} onChange={e=>setForm({...form,discount:e.target.value})}/></label>

          <label>Category <span className="required-mark">*</span>
            <select required value={form.category} onChange={e=>setForm({...form,category:e.target.value})} disabled={catalogLoading}>
              <option value="">{catalogLoading ? "Loading..." : "Select category"}</option>
              {categories.map(c=><option key={c._id} value={c.name}>{c.name}</option>)}
            </select>
          </label>

          <label>Brand <span className="required-mark">*</span>
            <select required value={form.brand} onChange={e=>setForm({...form,brand:e.target.value})} disabled={catalogLoading}>
              <option value="">{catalogLoading ? "Loading..." : "Select brand"}</option>
              {brands.map(b=><option key={b._id} value={b.name}>{b.name}</option>)}
            </select>
          </label>

          <label>Supplier
            <select value={form.supplier} onChange={e=>setForm({...form,supplier:e.target.value})} disabled={catalogLoading}>
              <option value="">No supplier</option>
              {suppliers.map(s=><option key={s._id} value={s._id}>{s.name}{s.company ? ` — ${s.company}` : ""}</option>)}
            </select>
          </label>

          <label>Image URL<input type="url" value={form.image} onChange={e=>setForm({...form,image:e.target.value})} placeholder="https://example.com/product.jpg"/></label>
          <label>Warranty<input value={form.warranty} onChange={e=>setForm({...form,warranty:e.target.value})} placeholder="e.g. 1 year"/></label>

          <label className="full">Description<textarea required value={form.description} onChange={e=>setForm({...form,description:e.target.value})}/></label>

          <div className="spec-box full">
            <strong>Specifications</strong>
            <div className="form-grid two-col">
              {Object.keys(blank.specifications).map(key =>
                <label key={key}>{key.charAt(0).toUpperCase()+key.slice(1)}
                  <input value={form.specifications?.[key] || ""} onChange={e=>setForm({...form,specifications:{...form.specifications,[key]:e.target.value}})}/>
                </label>
              )}
            </div>
          </div>

          <div className="modal-actions full">
            <button type="button" className="btn btn-secondary" onClick={closeModal}>Cancel</button>
            <button className="btn btn-primary" disabled={saving}>{saving ? <Spinner small/> : editing ? "Save changes" : "Create product"}</button>
          </div>
        </form>
      </Modal>}
    </>
  );
}
