import { useEffect, useState } from "react";
import { getSuppliers, getSupplierStats, createSupplier, updateSupplier, updateSupplierStatus, deleteSupplier } from "../../services/adminService";
import { getCategories } from "../../services/catalogService";
import { useAuth } from "../../context/AuthContext";
import PageHeader from "../../components/common/PageHeader";
import Table from "../../components/common/Table";
import Modal from "../../components/common/Modal";
import Alert from "../../components/common/Alert";
import Spinner from "../../components/common/Spinner";
import StatCard from "../../components/common/StatCard";
import { Factory, Users, CheckCircle2 } from "lucide-react";

const blank = { name:"", company:"", contactPerson:"", phone:"", email:"", address:"", suppliedCategories:[] };

const list = (response, keys) => {
  const d=response?.data?.data??response?.data??{};
  for(const k of keys) if(Array.isArray(d?.[k])) return d[k];
  return Array.isArray(d)?d:[];
};

export default function Suppliers(){
  const {user}=useAuth();
  const [items,setItems]=useState([]),[categories,setCategories]=useState([]),[stats,setStats]=useState({}),[loading,setLoading]=useState(true),[error,setError]=useState("");
  const [modal,setModal]=useState(false),[editing,setEditing]=useState(null),[form,setForm]=useState(blank);

  const load=async()=>{
    setLoading(true); setError("");
    try{
      const [s,c,st]=await Promise.allSettled([getSuppliers({limit:100}),getCategories({status:"active",limit:100}),getSupplierStats()]);
      if(s.status==="fulfilled") setItems(list(s.value,["suppliers","items"]));
      if(c.status==="fulfilled") setCategories(list(c.value,["categories","items"]));
      if(st.status==="fulfilled"){
        const d=st.value?.data?.data??st.value?.data??{};
        if(d.totalSuppliers!==undefined) setStats(d);
      }
    }catch(e){setError(e.response?.data?.message||"Unable to load suppliers")}
    finally{setLoading(false)}
  };
  useEffect(()=>{load()},[]);

  const close=()=>{setModal(false);setEditing(null);setForm(blank)};
  const save=async e=>{
    e.preventDefault();setError("");
    try{
      const payload={...form,suppliedCategories:form.suppliedCategories||[]};
      if(editing) await updateSupplier(editing._id,payload); else await createSupplier(payload);
      close(); await load();
    }catch(e){setError(e.response?.data?.message||"Save failed")}
  };

  const cols=[
    {key:"name",label:"Supplier"},
    {key:"company",label:"Company"},
    {key:"contactPerson",label:"Contact"},
    {key:"phone",label:"Phone"},
    {key:"suppliedCategories",label:"Categories",render:r=>(r.suppliedCategories||[]).join(", ")||"—"},
    {key:"status",label:"Status",render:r=><span className="status">{r.status}</span>},
    {key:"actions",label:"Actions",render:r=><div className="actions">
      <button className="btn btn-secondary btn-sm" onClick={()=>{setEditing(r);setForm({...blank,...r,suppliedCategories:r.suppliedCategories||[]});setModal(true)}}>Edit</button>
      <button className="btn btn-secondary btn-sm" onClick={async()=>{try{await updateSupplierStatus(r._id,r.status==="active"?"inactive":"active");await load()}catch(e){setError(e.response?.data?.message||"Status update failed")}}}>{r.status==="active"?"Disable":"Enable"}</button>
      <button className="btn btn-danger btn-sm" onClick={async()=>{if(!confirm("Delete this supplier?"))return;try{await deleteSupplier(r._id);await load()}catch(e){setError(e.response?.data?.message||"Delete failed")}}}>Delete</button>
    </div>}
  ];

  return <>
    <PageHeader title="Suppliers" subtitle="Admin-managed supplier records." action={<button className="btn btn-primary" onClick={()=>{setEditing(null);setForm(blank);setModal(true)}}>+ Add supplier</button>}/>
    <div className="stats-grid supplier-stats">
      <StatCard icon={<Factory/>} label="Total suppliers" value={stats.totalSuppliers ?? items.length}/>
      <StatCard icon={<CheckCircle2/>} label="Active" value={stats.activeSuppliers ?? items.filter(x=>x.status==="active").length}/>
      <StatCard icon={<Users/>} label="Inactive" value={stats.inactiveSuppliers ?? items.filter(x=>x.status==="inactive").length}/>
    </div>
    <Alert>{error}</Alert>
    {loading?<Spinner/>:<Table columns={cols} data={items} empty="No suppliers found."/>}
    {modal&&<Modal title={editing?"Edit supplier":"Add supplier"} onClose={close}>
      <form className="form-grid two-col" onSubmit={save}>
        <label>Name<input required value={form.name} onChange={e=>setForm({...form,name:e.target.value})}/></label>
        <label>Company<input required value={form.company} onChange={e=>setForm({...form,company:e.target.value})}/></label>
        <label>Contact person<input value={form.contactPerson} onChange={e=>setForm({...form,contactPerson:e.target.value})}/></label>
        <label>Phone<input value={form.phone} onChange={e=>setForm({...form,phone:e.target.value})}/></label>
        <label>Email<input type="email" value={form.email} onChange={e=>setForm({...form,email:e.target.value})}/></label>
        <label>Supplied categories<select multiple value={form.suppliedCategories||[]} onChange={e=>setForm({...form,suppliedCategories:Array.from(e.target.selectedOptions,o=>o.value)})}>{categories.map(c=><option key={c._id} value={c.name}>{c.name}</option>)}</select></label>
        <label className="full">Address<textarea value={form.address} onChange={e=>setForm({...form,address:e.target.value})}/></label>
        <button className="btn btn-primary full">{editing?"Save changes":"Create supplier"}</button>
      </form>
    </Modal>}
  </>;
}
