import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../../context/AuthContext";
import Alert from "../../components/common/Alert";

export default function Register() {
  const { signIn } = useAuth();
  const navigate = useNavigate();
  const [form,setForm]=useState({name:"",email:"",password:"",phone:"",address:""});
  const [error,setError]=useState("");
  const submit=async(e)=>{
    e.preventDefault(); setError("");
    try {
      const { register } = await import("../../services/authService");
      await register(form); await signIn({email:form.email,password:form.password}); navigate("/dashboard",{replace:true});
    } catch(err){setError(err.response?.data?.message || "Registration failed");}
  };
  return <div className="auth-page"><div className="auth-card wide">
    <div className="auth-brand"><div className="brand-mark large">TZ</div><h1>Create customer account</h1><p>Shop laptops, phones, tablets and accessories.</p></div>
    <Alert>{error}</Alert>
    <form onSubmit={submit} className="form-grid two-col">
      <label>Full name<input required value={form.name} onChange={e=>setForm({...form,name:e.target.value})}/></label>
      <label>Email<input required type="email" value={form.email} onChange={e=>setForm({...form,email:e.target.value})}/></label>
      <label>Password<input required minLength="6" type="password" value={form.password} onChange={e=>setForm({...form,password:e.target.value})}/></label>
      <label>Phone<input value={form.phone} onChange={e=>setForm({...form,phone:e.target.value})}/></label>
      <label className="full">Address<textarea rows="3" value={form.address} onChange={e=>setForm({...form,address:e.target.value})}/></label>
      <button className="btn btn-primary btn-block full">Create account</button>
    </form>
    <p className="auth-bottom">Already have an account? <Link to="/login">Sign in</Link></p>
  </div></div>;
}