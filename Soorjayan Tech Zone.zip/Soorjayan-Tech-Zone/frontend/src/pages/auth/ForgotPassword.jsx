import { useState } from "react";
import { Link } from "react-router-dom";
import { forgotPassword } from "../../services/authService";
import Alert from "../../components/common/Alert";

export default function ForgotPassword(){
  const [email,setEmail]=useState(""); const [msg,setMsg]=useState(""); const [error,setError]=useState("");
  const submit=async(e)=>{e.preventDefault();setError("");setMsg("");try{const r=await forgotPassword({email});setMsg(r.data?.message || "If the account exists, reset instructions are available.");}catch(err){setError(err.response?.data?.message || "Request failed");}};
  return <div className="auth-page"><div className="auth-card">
    <div className="auth-brand"><div className="brand-mark large">TZ</div><h1>Reset password</h1><p>Request a password reset for your account.</p></div>
    <Alert>{error}</Alert><Alert type="success">{msg}</Alert>
    <form onSubmit={submit} className="form-grid"><label>Email<input required type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="you@example.com"/></label><button className="btn btn-primary btn-block">Send reset request</button></form>
    <p className="auth-bottom"><Link to="/login">Back to sign in</Link></p>
  </div></div>;
}