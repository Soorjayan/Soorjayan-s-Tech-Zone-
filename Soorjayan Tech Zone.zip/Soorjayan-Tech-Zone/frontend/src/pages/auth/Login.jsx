import { useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { ArrowRight, Check, Eye, EyeOff, LockKeyhole, Mail, ShieldCheck, Sparkles, Truck, Boxes, UserRound, Sun, Moon } from "lucide-react";
import { useAuth } from "../../context/AuthContext";
import Alert from "../../components/common/Alert";
import Spinner from "../../components/common/Spinner";
import techLogo from "../../assets/tech-zone-s-logo.png";
import { getTheme, setTheme } from "../../utils/theme";

export default function Login() {
  const { signIn, signOut, loading } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [form, setForm] = useState({ email: "", password: "", role: "" });
  const [theme, setThemeState] = useState(() => getTheme());
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");

  const submit = async (e) => {
    e.preventDefault();
    setError("");
    try {
      const result = await signIn({ email: form.email, password: form.password });
      const loggedUser = result?.user || result?.data?.user;
      if (loggedUser?.role && loggedUser.role !== form.role) {
        signOut();
        setError(`This account is registered as ${loggedUser.role}. Please select the correct role.`);
        return;
      }
      navigate(location.state?.from?.pathname || "/dashboard", { replace: true });
    } catch (err) {
      setError(err.response?.data?.message || err.message || "Login failed");
    }
  };

  return <div className="auth-page auth-login-page">
    <div className="login-shell">
      <div className="login-main">
        <section className="login-showcase">
          <div className="showcase-orb orb-one" />
          <div className="showcase-orb orb-two" />
          <div className="showcase-top">
            <img className="showcase-logo-image" src={techLogo} alt="Soorjayan's Tech Zone"/>
            <strong>SOORJAYAN'S TECH ZONE</strong>
          </div>
          <div className="showcase-copy">
            <span className="showcase-pill"><Sparkles size={14}/> SMART STORE MANAGEMENT</span>
            <h1>Manage your<br/><span>electronics business</span><br/>with clarity.</h1>
            <p>Products, inventory, orders, customers and deliveries — organized in one simple workspace.</p>
            <div className="showcase-tags"><span>Products & inventory</span><span>Orders & delivery</span><span>Customer management</span></div>
          </div>
          <div className="showcase-feature-list">
            <div><span><Boxes size={15}/></span> Centralized product & stock management</div>
            <div><span><Truck size={15}/></span> Role-based delivery operations</div>
            <div><span><ShieldCheck size={15}/></span> Secure account access</div>
          </div>
        </section>

        <section className="login-form-panel">
          <div className="login-form-inner">
            <button type="button" className="login-theme-toggle" aria-label={`Switch to ${theme === "dark" ? "light" : "dark"} mode`} onClick={()=>setThemeState(setTheme(theme === "dark" ? "light" : "dark"))}>
              {theme === "dark" ? <Sun size={17}/> : <Moon size={17}/>}
            </button>
            <div className="mobile-auth-brand"><img src={techLogo} alt="Tech Zone"/><strong>Soorjayan's Tech Zone</strong></div>
            <span className="eyebrow">WELCOME BACK</span>
            <h2>Sign in to your account</h2>
            <p className="login-subtitle">Enter your details to continue to your workspace.</p>
            <Alert>{error}</Alert>
            <form onSubmit={submit} className="login-form">
              <label>Role<div className="input-with-icon login-role-select"><UserRound size={18}/><select value={form.role} onChange={e=>setForm({...form,role:e.target.value})} required><option value="" disabled>Select your role</option><option value="admin">Admin</option><option value="customer">Customer</option><option value="staff">Staff</option><option value="delivery">Delivery Staff</option></select></div></label>
              <label>Email address<div className="input-with-icon"><Mail size={18}/><input type="email" required autoComplete="email" value={form.email} onChange={e=>setForm({...form,email:e.target.value})} placeholder="you@example.com"/></div></label>
              <label>Password<div className="input-with-icon password-input"><LockKeyhole size={18}/><input type={showPassword ? "text" : "password"} required autoComplete="current-password" value={form.password} onChange={e=>setForm({...form,password:e.target.value})} placeholder="Enter your password"/><button type="button" className="password-toggle" aria-label={showPassword ? "Hide password" : "Show password"} onClick={()=>setShowPassword(v=>!v)}>{showPassword ? <EyeOff size={18}/> : <Eye size={18}/>}</button></div></label>
              <button className="btn btn-primary login-submit" disabled={loading}>{loading ? <Spinner small/> : <>Sign in <ArrowRight size={18}/></>}</button>
            </form>
            <div className="auth-links login-links"><Link to="/forgot-password">Forgot password?</Link><span>New customer? <Link to="/register">Create account</Link></span></div>
            <div className="secure-note"><ShieldCheck size={16}/> JWT-protected account access</div>
            <div className="login-note"><Check size={14}/> Your role determines the tools available after sign in.</div>
          </div>
        </section>
      </div>
      <footer className="login-copyright">© 2026 Soorjayan's Tech Zone · All rights reserved. · Privacy Policy</footer>
    </div>
  </div>;
}
