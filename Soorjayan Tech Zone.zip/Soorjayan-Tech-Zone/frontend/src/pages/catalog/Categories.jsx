import { useEffect, useRef, useState } from "react";
import { Camera, ImagePlus, Trash2 } from "lucide-react";
import { createCategory, getCategories, updateCategory, updateCategoryStatus, deleteCategory } from "../../services/catalogService";
import { getProducts } from "../../services/productService";
import { useAuth } from "../../context/AuthContext";
import PageHeader from "../../components/common/PageHeader";
import Table from "../../components/common/Table";
import Modal from "../../components/common/Modal";
import Alert from "../../components/common/Alert";
import Spinner from "../../components/common/Spinner";
import { getEntityImage, setEntityImage, removeEntityImage } from "../../utils/entityImage";

const normalize = (value) => String(value ?? "").trim().toLowerCase();
const extractProducts = (response) => {
  const data = response?.data?.data ?? response?.data ?? {};
  return data.products || data.items || (Array.isArray(data) ? data : []);
};

function ImageCell({ type, row, label }) {
  const [src, setSrc] = useState(() => getEntityImage(type, row));
  useEffect(() => {
    const refresh = () => setSrc(getEntityImage(type, row));
    window.addEventListener("techzone-entity-image-updated", refresh);
    return () => window.removeEventListener("techzone-entity-image-updated", refresh);
  }, [type, row]);
  return src ? <img className="entity-thumb" src={src} alt={`${label} ${row.name}`} /> : <div className="entity-thumb entity-thumb-placeholder"><ImagePlus size={17}/></div>;
}

export default function Categories() {
  const { user } = useAuth();
  const canManage = user?.role === "admin";
  const [items, setItems] = useState([]), [productCounts, setProductCounts] = useState({}), [loading, setLoading] = useState(true), [error, setError] = useState("");
  const [modal, setModal] = useState(false), [editing, setEditing] = useState(null), [form, setForm] = useState({ name: "", description: "", image: "" });
  const fileRef = useRef(null);

  const load = async () => {
    setLoading(true); setError("");
    try {
      const [categoryResponse, productResponse] = await Promise.allSettled([getCategories(), getProducts({ limit: 1000 })]);
      if (categoryResponse.status === "rejected") throw categoryResponse.reason;
      const data = categoryResponse.value?.data?.data ?? categoryResponse.value?.data ?? {};
      setItems(data.categories || data.items || (Array.isArray(data) ? data : []));
      if (productResponse.status === "fulfilled") {
        const counts = {};
        extractProducts(productResponse.value).forEach((product) => {
          const name = typeof product.category === "object" ? product.category?.name : product.category;
          const key = normalize(name); if (key) counts[key] = (counts[key] || 0) + 1;
        });
        setProductCounts(counts);
      } else setProductCounts({});
    } catch (e) { setError(e.response?.data?.message || "Unable to load categories"); }
    finally { setLoading(false); }
  };
  useEffect(() => { load(); }, []);

  const closeModal = () => { setModal(false); setEditing(null); setForm({ name: "", description: "", image: "" }); };
  const chooseImage = (e) => {
    const file = e.target.files?.[0]; if (!file) return;
    if (!file.type.startsWith("image/")) return setError("Please choose an image file.");
    if (file.size > 2 * 1024 * 1024) return setError("Category image must be 2 MB or smaller.");
    const reader = new FileReader(); reader.onload = () => setForm(f => ({ ...f, image: String(reader.result) })); reader.readAsDataURL(file);
  };
  const save = async (e) => {
    e.preventDefault(); setError("");
    try {
      const payload = { name: form.name, description: form.description };
      const response = editing ? await updateCategory(editing._id, payload) : await createCategory(payload);
      const saved = response?.data?.data || response?.data || editing || {};
      if (form.image) setEntityImage("category", { ...saved, _id: saved._id || editing?._id }, form.image);
      else if (editing && !getEntityImage("category", editing)) removeEntityImage("category", editing);
      closeModal(); await load();
    } catch (e) { setError(e.response?.data?.message || "Save failed"); }
  };
  const getCount = (row) => productCounts[normalize(row.name)] ?? row.productCount ?? 0;

  const cols = [
    { key: "image", label: "Image", render: row => <ImageCell type="category" row={row} label="Category"/> },
    { key: "name", label: "Name" }, { key: "description", label: "Description" }, { key: "productCount", label: "Products", render: getCount },
    { key: "status", label: "Status", render: row => <span className="status">{row.status}</span> },
    { key: "actions", label: "Actions", render: row => canManage && <div className="actions">
      <button className="btn btn-secondary btn-sm" onClick={() => { setEditing(row); setForm({ name: row.name || "", description: row.description || "", image: getEntityImage("category", row) }); setModal(true); }}>Edit</button>
      <button className="btn btn-secondary btn-sm" onClick={async () => { try { await updateCategoryStatus(row._id, row.status === "active" ? "inactive" : "active"); await load(); } catch (e) { setError(e.response?.data?.message || "Status update failed"); } }}>{row.status === "active" ? "Disable" : "Enable"}</button>
      <button className="btn btn-danger btn-sm" onClick={async () => { if (!confirm("Delete this category?")) return; try { await deleteCategory(row._id); removeEntityImage("category", row); await load(); } catch (e) { setError(e.response?.data?.message || "Delete failed"); } }}>Delete</button>
    </div> }
  ];

  return <>
    <PageHeader title="Categories" subtitle="Manage product categories with visual category images." action={canManage && <button className="btn btn-primary" onClick={() => { setEditing(null); setForm({ name: "", description: "", image: "" }); setModal(true); }}>+ Add category</button>}/>
    <Alert>{error}</Alert>
    {loading ? <Spinner/> : <Table columns={cols} data={items} empty="No categories found."/>}
    {modal && <Modal title={editing ? "Edit category" : "Add category"} onClose={closeModal}>
      <form className="form-grid" onSubmit={save}>
        <label>Name<input required value={form.name} onChange={e=>setForm({...form,name:e.target.value})}/></label>
        <label>Description<textarea value={form.description} onChange={e=>setForm({...form,description:e.target.value})}/></label>
        <div className="image-upload-field full"><strong>Category image</strong><div className="image-upload-row">{form.image ? <img className="upload-preview" src={form.image} alt="Category preview"/> : <div className="upload-preview upload-placeholder"><ImagePlus size={24}/></div>}<div><button type="button" className="btn btn-secondary" onClick={()=>fileRef.current?.click()}><Camera size={15}/> {form.image ? "Change image" : "Add image"}</button>{form.image && <button type="button" className="btn btn-danger btn-sm" onClick={()=>setForm({...form,image:""})}><Trash2 size={14}/> Remove</button>}<input ref={fileRef} hidden type="file" accept="image/png,image/jpeg,image/webp" onChange={chooseImage}/><small>PNG, JPG or WEBP · Maximum 2 MB</small></div></div></div>
        <div className="modal-actions"><button type="button" className="btn btn-secondary" onClick={closeModal}>Cancel</button><button className="btn btn-primary">{editing ? "Save changes" : "Create category"}</button></div>
      </form>
    </Modal>}
  </>;
}
