import { useEffect,useState } from "react";
import { useNavigate } from "react-router-dom";
import { createOrder } from "../../services/orderService";
import { getCart } from "../../services/cartService";
import { getProfile } from "../../services/profileService";
import PageHeader from "../../components/common/PageHeader";
import Alert from "../../components/common/Alert";
import Spinner from "../../components/common/Spinner";

export default function Checkout(){
  const nav=useNavigate();const [cart,setCart]=useState(null);const [form,setForm]=useState({name:"",phone:"",address:"",paymentMethod:"COD"});const [error,setError]=useState("");const [loading,setLoading]=useState(true);const [saving,setSaving]=useState(false);
  useEffect(()=>{(async()=>{try{const [c,p]=await Promise.all([getCart(),getProfile().catch(()=>null)]);setCart(c.data?.data||c.data);const u=p?.data?.data||p?.data;if(u)setForm(f=>({...f,name:u.name||"",phone:u.phone||"",address:u.address||""}));}catch(e){setError(e.response?.data?.message||"Unable to load checkout")}finally{setLoading(false)}})()},[]);
  const submit=async(e)=>{e.preventDefault();setSaving(true);setError("");try{const r=await createOrder(form);const order=r.data?.data||r.data;nav(`/my-orders`,{state:{created:order}})}catch(e){setError(e.response?.data?.message||"Unable to place order")}finally{setSaving(false)}};
  if(loading)return <div className="center-page"><Spinner/></div>;
  const total=cart?.totalAmount??cart?.total??0;
  return <><PageHeader title="Checkout" subtitle="Confirm delivery details and payment method."/><Alert>{error}</Alert><div className="checkout-layout"><form className="card form-grid" onSubmit={submit}><label>Name<input required value={form.name} onChange={e=>setForm({...form,name:e.target.value})}/></label><label>Phone<input required value={form.phone} onChange={e=>setForm({...form,phone:e.target.value})}/></label><label>Address<textarea required rows="4" value={form.address} onChange={e=>setForm({...form,address:e.target.value})}/></label><label>Payment method<select value={form.paymentMethod} onChange={e=>setForm({...form,paymentMethod:e.target.value})}><option value="COD">Cash on Delivery</option><option value="BANK_TRANSFER">Bank Transfer</option></select></label><button className="btn btn-primary" disabled={saving}>{saving?<Spinner small/>:"Place order"}</button></form><div className="card summary"><h2>Total</h2><div className="big-total">Rs. {Number(total).toLocaleString()}</div><p>Order status starts as PLACED. Payment status starts as PENDING.</p></div></div></>;
}