import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Minus, Plus, Trash2, ShoppingBag } from "lucide-react";
import { getCart, updateCart, removeFromCart } from "../../services/cartService";
import PageHeader from "../../components/common/PageHeader";
import Spinner from "../../components/common/Spinner";
import EmptyState from "../../components/common/EmptyState";
import Alert from "../../components/common/Alert";

function CartImage({ src, name }) {
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    setFailed(false);
  }, [src]);

  return (
    <div className="cart-thumb">
      {src && !failed ? (
        <img
          src={src}
          alt={name || "Product"}
          loading="lazy"
          onError={() => setFailed(true)}
        />
      ) : (
        <ShoppingBag size={24} />
      )}
    </div>
  );
}

export default function Cart() {
  const [cart, setCart] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const nav = useNavigate();

  const load = async () => {
    try {
      const response = await getCart();
      setCart(response.data?.data || response.data);
    } catch (e) {
      setError(e.response?.data?.message || "Unable to load cart");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, []);

  const change = async (item, quantity) => {
    try {
      await updateCart({
        productId: item.product?._id || item.productId,
        quantity
      });
      await load();
    } catch (e) {
      setError(e.response?.data?.message || "Unable to update cart");
    }
  };

  const remove = async (id) => {
    try {
      await removeFromCart(id);
      await load();
    } catch (e) {
      setError(e.response?.data?.message || "Unable to remove item");
    }
  };

  if (loading) {
    return (
      <div className="center-page">
        <Spinner />
      </div>
    );
  }

  const items = cart?.items || [];
  const total =
    cart?.totalAmount ??
    cart?.total ??
    items.reduce(
      (sum, item) =>
        sum +
        Number(item.price || item.product?.price || 0) *
          Number(item.quantity || 1),
      0
    );

  return (
    <>
      <PageHeader
        title="Shopping cart"
        subtitle={`${items.length} item(s) in your cart.`}
      />

      <Alert>{error}</Alert>

      {!items.length ? (
        <EmptyState
          title="Your cart is empty"
          text="Browse products and add something to your cart."
        />
      ) : (
        <div className="cart-layout">
          <div className="card cart-items">
            {items.map((item) => {
              const product = item.product || {};
              const id = product._id || item.productId;
              const price = Number(
                product.price ?? item.price ?? 0
              );

              return (
                <div className="cart-item" key={id}>
                  <CartImage
                    src={product.image}
                    name={product.name || item.name}
                  />

                  <div className="cart-main">
                    <h3>{product.name || item.name}</h3>
                    <span>
                      Rs. {price.toLocaleString()}
                    </span>
                  </div>

                  <div className="qty">
                    <button
                      onClick={() =>
                        change(
                          item,
                          Math.max(1, (item.quantity || 1) - 1)
                        )
                      }
                      aria-label="Decrease quantity"
                    >
                      <Minus size={14} />
                    </button>

                    <b>{item.quantity}</b>

                    <button
                      onClick={() =>
                        change(item, (item.quantity || 1) + 1)
                      }
                      aria-label="Increase quantity"
                    >
                      <Plus size={14} />
                    </button>
                  </div>

                  <strong>
                    Rs.{" "}
                    {(price * Number(item.quantity || 1)).toLocaleString()}
                  </strong>

                  <button
                    className="icon-btn danger"
                    onClick={() => remove(id)}
                    aria-label="Remove item"
                  >
                    <Trash2 size={17} />
                  </button>
                </div>
              );
            })}
          </div>

          <div className="card summary">
            <h2>Order summary</h2>

            <div className="summary-line">
              <span>Subtotal</span>
              <strong>Rs. {Number(total).toLocaleString()}</strong>
            </div>

            <div className="summary-line">
              <span>Delivery</span>
              <strong>Calculated at checkout</strong>
            </div>

            <button
              className="btn btn-primary btn-block"
              onClick={() => nav("/checkout")}
            >
              Proceed to checkout
            </button>

            <Link className="continue" to="/products">
              Continue shopping
            </Link>
          </div>
        </div>
      )}
    </>
  );
}
