import { useEffect, useMemo, useState } from "react";
import {
  ArrowRight,
  BarChart3,
  Box,
  ClipboardList,
  Clock3,
  DollarSign,
  Package,
  ShoppingBag,
  Truck,
  Users,
  Warehouse,
  MapPin,
  CheckCircle2,
  AlertTriangle,
  UserRound,
} from "lucide-react";
import { Link } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { getDashboard, getCustomers } from "../services/adminService";
import { getMyOrders, getOrders } from "../services/orderService";
import { getMyDeliveryOrders } from "../services/deliveryService";
import { getLowStock } from "../services/inventoryService";
import StatCard from "../components/common/StatCard";
import PageHeader from "../components/common/PageHeader";
import Spinner from "../components/common/Spinner";
import Alert from "../components/common/Alert";

const money = (value) => `Rs. ${Number(value || 0).toLocaleString()}`;
const prettyStatus = (status = "") => status.replaceAll("_", " ");
const initials = (name = "User") => name.split(" ").map((x) => x[0]).slice(0, 2).join("").toUpperCase();

function QuickAction({ icon: Icon, title, text, to }) {
  return (
    <Link className="quick-action" to={to}>
      <span className="quick-action-icon"><Icon size={19} /></span>
      <span><strong>{title}</strong><small>{text}</small></span>
      <ArrowRight size={17} className="quick-action-arrow" />
    </Link>
  );
}

function OrderMiniList({ orders, delivery = false, linkTo = "/orders" }) {
  if (!orders?.length) return <div className="dashboard-empty"><ClipboardList size={22}/><span>No recent orders to display.</span></div>;
  return (
    <div className="dashboard-order-list">
      {orders.slice(0, 5).map((order) => (
        <Link to={linkTo} className="dashboard-order-row" key={order._id}>
          <span className="order-ref">#{String(order._id).slice(-8)}</span>
          <span className="order-person">{delivery ? order.user?.name || "Customer" : order.user?.name || order.shippingAddress?.name || "Customer"}</span>
          <span className={`status-pill status-${String(order.orderStatus || "").toLowerCase()}`}>{prettyStatus(order.orderStatus)}</span>
          <strong>{money(order.totalAmount)}</strong>
        </Link>
      ))}
    </div>
  );
}

export default function Dashboard() {
  const { user } = useAuth();
  const [state, setState] = useState({ loading: true, error: "", data: {}, orders: [], lowStock: [], customers: 0 });

  useEffect(() => {
    let active = true;
    (async () => {
      try {
        const role = user?.role;
        if (role === "admin") {
          const [dashboardResponse, ordersResponse] = await Promise.all([
            getDashboard(),
            getOrders({ limit: 5, sort: "newest" }),
          ]);
          if (!active) return;
          const dashboard = dashboardResponse.data?.data || dashboardResponse.data || {};
          const orders = ordersResponse.data?.data || [];
          setState({ loading: false, error: "", data: dashboard.summary || dashboard, orders, lowStock: [], customers: dashboard.summary?.totalCustomers || 0 });
        } else if (role === "staff") {
          const jobs = [];
          const canOrders = !!user?.permissions?.orderProcessing;
          const canInventory = !!user?.permissions?.inventoryManagement;
          const canCustomers = !!user?.permissions?.customerManagement;
          if (canOrders) jobs.push(getOrders({ limit: 5, sort: "newest" })); else jobs.push(Promise.resolve(null));
          if (canInventory) jobs.push(getLowStock()); else jobs.push(Promise.resolve(null));
          if (canCustomers) jobs.push(getCustomers({ limit: 1 })); else jobs.push(Promise.resolve(null));
          const [ordersResponse, lowResponse, customersResponse] = await Promise.all(jobs);
          if (!active) return;
          const orders = ordersResponse?.data?.data || [];
          const lowStock = lowResponse?.data?.data || [];
          const customerBody = customersResponse?.data || {};
          setState({
            loading: false,
            error: "",
            data: {
              orders: orders.length,
              pending: orders.filter((o) => ["PLACED", "CONFIRMED", "PROCESSING"].includes(o.orderStatus)).length,
              delivered: orders.filter((o) => o.orderStatus === "DELIVERED").length,
              outForDelivery: orders.filter((o) => o.orderStatus === "OUT_FOR_DELIVERY").length,
            },
            orders,
            lowStock,
            customers: customerBody.totalCustomers || customerBody.count || 0,
          });
        } else if (role === "delivery") {
          const response = await getMyDeliveryOrders();
          if (!active) return;
          const orders = response.data?.data || [];
          setState({
            loading: false,
            error: "",
            data: {
              assigned: orders.length,
              outForDelivery: orders.filter((o) => o.orderStatus === "OUT_FOR_DELIVERY").length,
              pending: orders.filter((o) => ["PLACED", "CONFIRMED", "PROCESSING", "SHIPPED"].includes(o.orderStatus)).length,
              delivered: orders.filter((o) => o.orderStatus === "DELIVERED").length,
              value: orders.filter((o) => o.orderStatus !== "CANCELLED").reduce((sum, o) => sum + Number(o.totalAmount || 0), 0),
            },
            orders,
            lowStock: [],
            customers: 0,
          });
        } else if (role === "customer") {
          const response = await getMyOrders({ limit: 100 });
          if (!active) return;
          const body = response.data?.data || response.data || {};
          const orders = body.orders || (Array.isArray(body) ? body : []);
          setState({
            loading: false,
            error: "",
            data: {
              orders: orders.length,
              delivered: orders.filter((o) => o.orderStatus === "DELIVERED").length,
              pending: orders.filter((o) => !["DELIVERED", "CANCELLED"].includes(o.orderStatus)).length,
            },
            orders,
            lowStock: [],
            customers: 0,
          });
        }
      } catch (error) {
        if (!active) return;
        setState((current) => ({ ...current, loading: false, error: error.response?.data?.message || "Unable to load dashboard information." }));
      }
    })();
    return () => { active = false; };
  }, [user]);

  const { loading, error, data: d, orders, lowStock } = state;
  const role = user?.role;
  const firstName = user?.name?.split(" ")[0] || "there";
  const customerOrderTotal = useMemo(() => orders.reduce((sum, o) => sum + Number(o.totalAmount || 0), 0), [orders]);

  if (loading) return <div className="center-page"><Spinner /></div>;

  if (role === "admin") {
    return <div className="dashboard-page">
      <PageHeader title={`Good day, ${firstName}`} subtitle="Here's the latest overview of your electronics store." />
      <Alert>{error}</Alert>
      <section className="dashboard-hero admin-hero">
        <div><span className="eyebrow">STORE OVERVIEW</span><h2>Your business at a glance</h2><p>Monitor products, customers, orders and inventory from one place.</p></div>
        <Link className="btn btn-primary" to="/products">Manage products <ArrowRight size={16}/></Link>
      </section>
      <div className="stats-grid dashboard-stats">
        <StatCard icon={<Package/>} label="Total products" value={d.totalProducts}/>
        <StatCard icon={<Users/>} label="Customers" value={d.totalCustomers}/>
        <StatCard icon={<ShoppingBag/>} label="Orders" value={d.totalOrders}/>
        <StatCard icon={<DollarSign/>} label="Revenue" value={money(d.totalRevenue)}/>
        <StatCard icon={<AlertTriangle/>} label="Low stock" value={d.lowStockProducts}/>
        <StatCard icon={<CheckCircle2/>} label="Delivered" value={d.deliveredOrders}/>
        <StatCard icon={<Truck/>} label="Active suppliers" value={d.activeSuppliers}/>
        <StatCard icon={<Clock3/>} label="Pending orders" value={d.pendingOrders}/>
      </div>
      <div className="dashboard-two-column">
        <section className="card dashboard-section"><div className="section-heading"><div><span className="eyebrow">OPERATIONS</span><h3>Quick actions</h3></div></div><div className="quick-action-grid">
          <QuickAction icon={Package} title="Products" text="Add or update catalog items" to="/products" />
          <QuickAction icon={Warehouse} title="Inventory" text="Review stock movements" to="/inventory" />
          <QuickAction icon={ClipboardList} title="Orders" text="Process customer orders" to="/orders" />
          <QuickAction icon={Truck} title="Delivery team" text="Manage delivery staff" to="/delivery-staff" />
        </div></section>
        <section className="card dashboard-section attention-card"><div className="section-heading"><div><span className="eyebrow">ATTENTION</span><h3>Stock watch</h3></div><AlertTriangle size={20}/></div><div className="attention-panel"><strong>{d.lowStockProducts || 0} item{d.lowStockProducts === 1 ? "" : "s"}</strong><p>currently marked as low stock. Review inventory to keep popular electronics available.</p><Link to="/inventory">Open inventory <ArrowRight size={15}/></Link></div></section>
      </div>
      <section className="card dashboard-section"><div className="section-heading"><div><span className="eyebrow">LATEST ACTIVITY</span><h3>Recent orders</h3></div><Link to="/orders" className="text-link">View all <ArrowRight size={15}/></Link></div><OrderMiniList orders={orders}/></section>
    </div>;
  }

  if (role === "staff") {
    const canOrders = !!user?.permissions?.orderProcessing;
    const canInventory = !!user?.permissions?.inventoryManagement;
    const canCustomers = !!user?.permissions?.customerManagement;
    return <div className="dashboard-page staff-dashboard">
      <PageHeader title={`Good day, ${firstName}`} subtitle="Your staff workspace for daily store operations." />
      <Alert>{error}</Alert>
      <section className="dashboard-hero staff-hero"><div><span className="eyebrow">STAFF WORKSPACE</span><h2>Keep today's operations moving</h2><p>Use your assigned tools to manage products, inventory, customers and orders efficiently.</p></div><div className="workspace-badge"><UserRound size={18}/><span>Staff account</span></div></section>
      <div className="stats-grid dashboard-stats">
        {canOrders && <StatCard icon={<ClipboardList/>} label="Recent orders" value={d.orders}/>} 
        {canOrders && <StatCard icon={<Clock3/>} label="Pending orders" value={d.pending}/>} 
        {canOrders && <StatCard icon={<Truck/>} label="Out for delivery" value={d.outForDelivery}/>} 
        {canInventory && <StatCard icon={<AlertTriangle/>} label="Low stock items" value={lowStock.length}/>} 
        {canOrders && <StatCard icon={<CheckCircle2/>} label="Delivered" value={d.delivered}/>} 
        {canCustomers && <StatCard icon={<Users/>} label="Customer access" value="Enabled"/>}
      </div>
      <div className="dashboard-two-column staff-main-grid">
        <section className="card dashboard-section"><div className="section-heading"><div><span className="eyebrow">YOUR TOOLS</span><h3>Quick actions</h3></div></div><div className="quick-action-grid">
          <QuickAction icon={Package} title="Products" text="View and maintain product catalog" to="/products" />
          {canInventory && <QuickAction icon={Warehouse} title="Inventory" text="Check stock and update quantities" to="/inventory" />}
          {canOrders && <QuickAction icon={ClipboardList} title="Orders" text="Process and update customer orders" to="/orders" />}
          {canCustomers && <QuickAction icon={Users} title="Customers" text="Review customer information" to="/customers" />}
        </div></section>
        <section className="card dashboard-section"><div className="section-heading"><div><span className="eyebrow">INVENTORY</span><h3>Low-stock watch</h3></div><Warehouse size={20}/></div>{canInventory && lowStock.length ? <div className="low-stock-list">{lowStock.slice(0, 5).map((p)=><Link to="/inventory" key={p._id}><span><strong>{p.name}</strong><small>{p.category?.name || "Product"}</small></span><b>{p.stock} left</b></Link>)}</div> : <div className="dashboard-empty"><CheckCircle2 size={22}/><span>{canInventory ? "No low-stock items right now." : "Inventory access is not assigned to your account."}</span></div>}</section>
      </div>
      {canOrders && <section className="card dashboard-section"><div className="section-heading"><div><span className="eyebrow">ORDER QUEUE</span><h3>Latest customer orders</h3></div><Link to="/orders" className="text-link">Open orders <ArrowRight size={15}/></Link></div><OrderMiniList orders={orders}/></section>}
    </div>;
  }

  if (role === "delivery") {
    return <div className="dashboard-page delivery-dashboard">
      <PageHeader title={`Good day, ${firstName}`} subtitle="Your delivery workspace for today's assigned orders." />
      <Alert>{error}</Alert>
      <section className="dashboard-hero delivery-hero"><div><span className="eyebrow">DELIVERY WORKSPACE</span><h2>Stay on top of every delivery</h2><p>Review assigned orders, customer details and delivery progress from one place.</p></div><Link className="btn btn-primary" to="/orders">Open my deliveries <ArrowRight size={16}/></Link></section>
      <div className="stats-grid dashboard-stats">
        <StatCard icon={<ClipboardList/>} label="Assigned orders" value={d.assigned}/>
        <StatCard icon={<Truck/>} label="Out for delivery" value={d.outForDelivery}/>
        <StatCard icon={<Clock3/>} label="Needs attention" value={d.pending}/>
        <StatCard icon={<CheckCircle2/>} label="Delivered" value={d.delivered}/>
      </div>
      <div className="dashboard-two-column">
        <section className="card dashboard-section"><div className="section-heading"><div><span className="eyebrow">DELIVERY QUEUE</span><h3>Assigned orders</h3></div><span className="section-count">{d.assigned || 0}</span></div><OrderMiniList orders={orders} delivery /></section>
        <section className="card dashboard-section delivery-summary"><div className="section-heading"><div><span className="eyebrow">TODAY'S WORK</span><h3>Delivery summary</h3></div><MapPin size={20}/></div><div className="delivery-summary-box"><span>Total order value</span><strong>{money(d.value)}</strong><p>Keep customers updated as each assigned order moves through the delivery process.</p><Link to="/orders">Update delivery status <ArrowRight size={15}/></Link></div><div className="delivery-checklist"><div><CheckCircle2 size={17}/><span>Review customer and address details</span></div><div><Truck size={17}/><span>Update status after each delivery step</span></div><div><UserRound size={17}/><span>Use your profile for contact details</span></div></div></section>
      </div>
    </div>;
  }

  return <div className="dashboard-page customer-dashboard">
    <PageHeader title={`Good day, ${firstName}`} subtitle="Welcome back to Soorjayan's Tech Zone." />
    <Alert>{error}</Alert>
    <section className="dashboard-hero customer-hero"><div><span className="eyebrow">CUSTOMER SPACE</span><h2>Everything you need, in one place</h2><p>Explore electronics, manage your cart and keep track of your purchases.</p></div><Link className="btn btn-primary" to="/products">Shop products <ArrowRight size={16}/></Link></section>
    <div className="stats-grid dashboard-stats mini-stats"><StatCard icon={<ShoppingBag/>} label="My orders" value={d.orders}/><StatCard icon={<Clock3/>} label="In progress" value={d.pending}/><StatCard icon={<CheckCircle2/>} label="Delivered" value={d.delivered}/><StatCard icon={<DollarSign/>} label="Order value" value={money(customerOrderTotal)}/></div>
    <div className="dashboard-two-column"><section className="card dashboard-section"><div className="section-heading"><div><span className="eyebrow">SHOPPING</span><h3>Quick actions</h3></div></div><div className="quick-action-grid"><QuickAction icon={Package} title="Browse products" text="Find laptops, phones and accessories" to="/products"/><QuickAction icon={ShoppingBag} title="My cart" text="Review items before checkout" to="/cart"/><QuickAction icon={ClipboardList} title="My orders" text="Track your recent purchases" to="/my-orders"/><QuickAction icon={UserRound} title="My profile" text="Manage your account details" to="/profile"/></div></section><section className="card dashboard-section"><div className="section-heading"><div><span className="eyebrow">RECENT</span><h3>Your latest orders</h3></div></div><OrderMiniList orders={orders} linkTo="/my-orders"/></section></div>
  </div>;
}
