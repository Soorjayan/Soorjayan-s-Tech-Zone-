import { useEffect, useState } from "react";
import { Boxes, AlertTriangle, PackageX } from "lucide-react";
import { useAuth } from "../../context/AuthContext";
import { getInventory, getInventoryStats, addStock, reduceStock } from "../../services/inventoryService";
import PageHeader from "../../components/common/PageHeader";
import StatCard from "../../components/common/StatCard";
import Table from "../../components/common/Table";
import Modal from "../../components/common/Modal";
import Alert from "../../components/common/Alert";
import Spinner from "../../components/common/Spinner";

const calculateStatsFromItems = (items = []) => {
  const products = Array.isArray(items) ? items : [];

  return {
    totalUnits: products.reduce((sum, product) => sum + Number(product.stock || 0), 0),
    lowStockProducts: products.filter((product) => {
      const stock = Number(product.stock || 0);
      const threshold = Number(product.lowStockThreshold ?? 5);
      return stock > 0 && stock <= threshold;
    }).length,
    outOfStockProducts: products.filter(
      (product) => Number(product.stock || 0) === 0
    ).length,
  };
};

const normalizeInventory = (response) => {
  const data = response?.data?.data ?? response?.data ?? {};

  if (Array.isArray(data)) return data;
  if (Array.isArray(data.products)) return data.products;
  if (Array.isArray(data.items)) return data.items;

  return [];
};

export default function Inventory() {
  const { user } = useAuth();

  const [items, setItems] = useState([]);
  const [stats, setStats] = useState({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [modal, setModal] = useState(null);
  const [qty, setQty] = useState(1);

  const load = async () => {
    setLoading(true);
    setError("");

    try {
      // The backend currently exposes /inventory/stats to Admin only.
      // Staff can still access /inventory when they have inventoryManagement
      // permission, so calculate their summary cards from the inventory list.
      const inventoryResponse = await getInventory();
      const inventoryItems = normalizeInventory(inventoryResponse);

      setItems(inventoryItems);

      const fallbackStats = calculateStatsFromItems(inventoryItems);

      if (user?.role === "admin") {
        try {
          const statsResponse = await getInventoryStats();
          const rawStats =
            statsResponse?.data?.data ?? statsResponse?.data ?? {};
          const backendStats = rawStats.summary ?? rawStats;

          setStats({
            ...fallbackStats,
            ...backendStats,
          });
        } catch {
          // Admin can still use the calculated values if the statistics
          // endpoint is temporarily unavailable.
          setStats(fallbackStats);
        }
      } else {
        setStats(fallbackStats);
      }
    } catch (e) {
      setError(
        e.response?.data?.message || "Unable to load inventory"
      );
      setItems([]);
      setStats({});
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, [user?.role]);

  const submit = async (e) => {
    e.preventDefault();

    try {
      const quantity = Number(qty);

      if (!Number.isInteger(quantity) || quantity < 1) {
        setError("Quantity must be a positive integer");
        return;
      }

      if (modal.type === "add") {
        await addStock(modal.product._id, { quantity });
      } else {
        await reduceStock(modal.product._id, { quantity });
      }

      setModal(null);
      setQty(1);
      await load();
    } catch (e) {
      setError(
        e.response?.data?.message || "Stock update failed"
      );
    }
  };

  const cols = [
    {
      key: "name",
      label: "Product",
    },
    {
      key: "sku",
      label: "SKU",
      render: (row) => row.sku || "—",
    },
    {
      key: "stock",
      label: "Stock",
      render: (row) => row.stock ?? 0,
    },
    {
      key: "lowStockThreshold",
      label: "Low threshold",
      render: (row) => row.lowStockThreshold ?? 5,
    },
    {
      key: "status",
      label: "Status",
      render: (row) => {
        const stock = Number(row.stock || 0);
        const threshold = Number(row.lowStockThreshold ?? 5);

        if (stock === 0) {
          return (
            <span className="status status-cancelled">
              Out of stock
            </span>
          );
        }

        if (stock <= threshold) {
          return (
            <span className="status status-placed">
              Low stock
            </span>
          );
        }

        return (
          <span className="status status-delivered">
            Healthy
          </span>
        );
      },
    },
    {
      key: "actions",
      label: "Actions",
      render: (row) => (
        <div className="actions">
          <button
            className="btn btn-primary btn-sm"
            onClick={() =>
              setModal({
                type: "add",
                product: row,
              })
            }
          >
            Add
          </button>

          <button
            className="btn btn-secondary btn-sm"
            disabled={!row.stock}
            onClick={() =>
              setModal({
                type: "reduce",
                product: row,
              })
            }
          >
            Reduce
          </button>
        </div>
      ),
    },
  ];

  return (
    <>
      <PageHeader
        title="Inventory"
        subtitle="Monitor stock levels and stock movements."
      />

      <div className="stats-grid">
        <StatCard
          icon={<Boxes />}
          label="Total units"
          value={stats.totalUnits ?? stats.totalStock ?? 0}
        />

        <StatCard
          icon={<AlertTriangle />}
          label="Low stock"
          value={
            stats.lowStockProducts ??
            stats.lowStockCount ??
            stats.lowStock ??
            0
          }
        />

        <StatCard
          icon={<PackageX />}
          label="Out of stock"
          value={
            stats.outOfStockProducts ??
            stats.outOfStockCount ??
            stats.outOfStock ??
            0
          }
        />
      </div>

      <Alert>{error}</Alert>

      {loading ? (
        <div className="center-page">
          <Spinner />
        </div>
      ) : (
        <Table
          columns={cols}
          data={items}
          empty="No inventory records found."
        />
      )}

      {modal && (
        <Modal
          title={`${modal.type === "add" ? "Add" : "Reduce"} stock`}
          onClose={() => {
            setModal(null);
            setQty(1);
          }}
        >
          <form className="form-grid" onSubmit={submit}>
            <p>
              <strong>{modal.product.name}</strong>
            </p>

            <p className="muted">
              Current stock: {modal.product.stock ?? 0}
            </p>

            <label>
              Quantity
              <input
                type="number"
                min="1"
                step="1"
                required
                value={qty}
                onChange={(e) => setQty(e.target.value)}
              />
            </label>

            <button className="btn btn-primary" type="submit">
              Confirm
            </button>
          </form>
        </Modal>
      )}
    </>
  );
}
