import api from "./api";

export const getCategories = (params = {}) => api.get("/categories", { params });
export const createCategory = (data) => api.post("/categories", data);
export const updateCategory = (id, data) => api.put(`/categories/${id}`, data);
export const updateCategoryStatus = (id, status) => api.patch(`/categories/${id}/status`, { status });
export const deleteCategory = (id) => api.delete(`/categories/${id}`);

export const getBrands = (params = {}) => api.get("/brands", { params });
export const createBrand = (data) => api.post("/brands", data);
export const updateBrand = (id, data) => api.put(`/brands/${id}`, data);
export const updateBrandStatus = (id, status) => api.patch(`/brands/${id}/status`, { status });
export const deleteBrand = (id) => api.delete(`/brands/${id}`);