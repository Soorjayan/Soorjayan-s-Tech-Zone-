import api from "./api";

export const getMyDeliveryOrders = () => api.get("/delivery-staff/my-orders");
