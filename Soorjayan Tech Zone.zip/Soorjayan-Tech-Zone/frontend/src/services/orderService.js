import api from "./api";

export const createOrder = (data) => api.post("/orders", data);
export const getOrders = (params = {}) => api.get("/orders", { params });
export const getMyOrders = (params = {}) => api.get("/orders/my-orders", { params });
export const getOrder = (id) => api.get(`/orders/${id}`);
export const getMyOrder = (id) => api.get(`/orders/my-orders/${id}`);
export const updateOrderStatus = (id, data) => api.put(`/orders/${id}/status`, data);
export const cancelOrder = (id, data = {}) => api.put(`/orders/${id}/cancel`, data);
export const assignDelivery = (id, data) => api.patch(`/orders/${id}/assign-delivery`, data);
export const getOrderStats = () => api.get("/orders/stats");