import api from "./api";

export const getDashboard = () => api.get("/dashboard");

export const getCustomers = (params = {}) => api.get("/customers", { params });
export const getCustomer = (id) => api.get(`/customers/${id}`);
export const getCustomerStats = () => api.get("/customers/stats");
export const updateCustomer = (id, data) => api.put(`/customers/${id}`, data);
export const updateCustomerStatus = (id, status) =>
  api.patch(`/customers/${id}/status`, { status });

export const getStaff = (params = {}) => api.get("/staff", { params });
export const createStaff = (data) => api.post("/staff", data);
export const updateStaff = (id, data) => api.put(`/staff/${id}`, data);
export const updateStaffStatus = (id, status) =>
  api.patch(`/staff/${id}/status`, { status });
export const deleteStaff = (id) => api.delete(`/staff/${id}`);

export const getDeliveryStaff = (params = {}) =>
  api.get("/delivery-staff", { params });
export const createDeliveryStaff = (data) =>
  api.post("/delivery-staff", data);
export const updateDeliveryStaff = (id, data) =>
  api.put(`/delivery-staff/${id}`, data);
export const updateDeliveryStaffStatus = (id, status) =>
  api.patch(`/delivery-staff/${id}/status`, { status });
export const deleteDeliveryStaff = (id) =>
  api.delete(`/delivery-staff/${id}`);

export const getSuppliers = (params = {}) =>
  api.get("/suppliers", { params });
export const getSupplier = (id) => api.get(`/suppliers/${id}`);
export const getSupplierStats = () => api.get("/suppliers/stats");
export const createSupplier = (data) => api.post("/suppliers", data);
export const updateSupplier = (id, data) =>
  api.put(`/suppliers/${id}`, data);
export const updateSupplierStatus = (id, status) =>
  api.patch(`/suppliers/${id}/status`, { status });
export const deleteSupplier = (id) => api.delete(`/suppliers/${id}`);
