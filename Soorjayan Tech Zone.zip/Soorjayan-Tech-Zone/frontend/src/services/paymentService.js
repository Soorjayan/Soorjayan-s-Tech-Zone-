import api from "./api";

export const updatePaymentStatus = (id, paymentStatus, note = "") =>
  api.patch(`/payments/${id}/payment-status`, { paymentStatus, note });

export const getPaymentHistory = (id) => api.get(`/payments/${id}/history`);
export const getPaymentStats = () => api.get("/payments/stats");
