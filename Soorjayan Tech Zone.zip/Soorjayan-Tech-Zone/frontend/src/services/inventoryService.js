import api from "./api";

export const getInventory = (params = {}) => api.get("/inventory", { params });
export const getInventoryStats = () => api.get("/inventory/stats");
export const getLowStock = () => api.get("/inventory/low-stock");
export const getOutOfStock = () => api.get("/inventory/out-of-stock");
export const getMovements = (params = {}) => api.get("/inventory/movements", { params });
export const addStock = (id, data) => api.put(`/inventory/${id}/add-stock`, data);
export const reduceStock = (id, data) => api.put(`/inventory/${id}/reduce-stock`, data);
export const adjustStock = (id, data) => api.put(`/inventory/${id}/adjust-stock`, data);