# Soorjayan's Tech Zone — React Frontend

Frontend for the Electronics E-Commerce & Product Catalog Management System.

## Requirements
- Node.js 18+
- Backend running at `http://localhost:5000`

## Setup
```bash
cd frontend
npm install
copy .env.example .env
npm run dev
```

For macOS/Linux:
```bash
cp .env.example .env
```

The Vite frontend runs on:
`http://localhost:5173`

The API base URL is controlled by:
`VITE_API_URL=http://localhost:5000/api`

## Main roles
- Admin
- Staff
- Delivery Staff
- Customer

Supplier records are managed by Admin; there is no supplier login in the current backend design.

## Main frontend modules
- Authentication
- Role-based navigation
- Dashboard
- Product catalog
- Product details
- Categories
- Brands
- Inventory
- Suppliers
- Customers
- Staff management
- Delivery staff management
- Orders
- Customer cart
- Checkout
- Customer order history
- Profile/password

## Important
Do not commit `.env` or real secrets. The frontend stores the JWT returned by the backend in browser local storage for this internship/demo implementation.

## Latest fixes
- Dashboard reads the backend `data.summary` structure correctly.
- Inventory summary cards read `data.summary` and the actual `totalUnits`, `lowStockProducts`, and `outOfStockProducts` fields.
- Product cards and product details now show a clean placeholder when a product image URL is missing or cannot be loaded.
- Category/brand product counts are handled case-insensitively by the backend list aggregation.


## Product form notes

The backend Product model requires:
- name
- description
- price
- stock
- category
- brand

Supplier is optional and must be a valid Supplier ObjectId. The frontend therefore uses a supplier dropdown and omits the supplier property when `No supplier` is selected. This avoids the Mongoose error caused by sending an empty string as an ObjectId.

The current UI also supports product editing, admin-only deletion, specifications, warranty, discount, search/filter/sort and pagination.
- Staff inventory summary cards are calculated from the inventory list because the current backend exposes `/inventory/stats` to Admin only; Staff still receive accurate Total Units, Low Stock, and Out of Stock values.
