# Soorjayan's Tech Zone — Interface Refresh

The frontend has been visually refreshed to follow a clean, modern electronics-management dashboard style inspired by the supplied reference image, while preserving the application's existing roles and functionality.

## Main UI changes
- Modern dark-blue sidebar with active navigation states
- Clean white top navigation bar with user/role information
- Blue-accent dashboard cards and softer page backgrounds
- Refreshed admin dashboard with quick actions and stock attention panel
- Refreshed product cards, filters, tables, forms and modals
- Redesigned login page with a split showcase/login layout
- Improved spacing, typography, borders, shadows and status badges
- Responsive sidebar and mobile layouts
- Existing routes, API services and business functionality are preserved

## Important
- `.env` is intentionally not included in the distribution ZIP.
- `node_modules` is intentionally not included.
- Keep your existing local `.env` when running the frontend.
