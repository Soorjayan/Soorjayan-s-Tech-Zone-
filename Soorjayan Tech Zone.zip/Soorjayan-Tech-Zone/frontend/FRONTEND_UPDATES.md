# Soorjayan's Tech Zone — UI Refresh

This frontend keeps the existing API, routes, authentication and role-based permissions while refreshing the visual experience.

## Main UI changes

- Split-screen login interface inspired by the supplied reference image.
- Dark-blue Tech Zone brand panel with business capabilities and secure-access messaging.
- Cleaner application shell with:
  - consistent blue active navigation
  - icon containers that use the blue theme instead of white-looking circles
  - user/avatar treatment
  - breadcrumb-style top bar
  - improved mobile navigation
- Role-specific dashboards for:
  - Admin
  - Staff
  - Delivery Staff
  - Customer
- Staff dashboard now shows useful operational information based on the staff member's permissions.
- Delivery dashboard now shows assigned orders, delivery progress and a delivery-work checklist.
- Admin dashboard includes business overview, quick actions, stock watch and recent orders.
- Customer dashboard includes shopping shortcuts and order summary.
- Shared cards, badges, tables, forms and responsive spacing were refined across the application.

## Files substantially changed

- `src/layouts/AppLayout.jsx`
- `src/pages/Dashboard.jsx`
- `src/pages/auth/Login.jsx`
- `src/index.css`

## Preserved

- Existing API services and endpoints.
- Existing role-based route protection.
- Existing product, category, brand, inventory, supplier, customer, staff, delivery and order functionality.
- Order-to-delivery assignment flow.
- Existing `.env.example`.

## Important

The package intentionally excludes `.env` and `node_modules`. Keep your local `.env` file in the frontend directory when running the application.
