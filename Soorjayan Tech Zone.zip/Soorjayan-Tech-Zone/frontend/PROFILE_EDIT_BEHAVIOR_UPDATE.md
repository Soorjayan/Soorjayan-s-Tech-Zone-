# Profile Edit Behavior Update

The Profile information section now uses a two-step button flow:

1. Initial state: **Edit profile**
2. Click **Edit profile** -> fields become editable and the button changes to **Save profile**
3. Modify Name, Phone, and Address
4. Click **Save profile** -> the API update is sent
5. After a successful save, the fields become read-only and the button returns to **Edit profile**

The profile form no longer submits/saves automatically through the form submit event. The profile is saved only when the user explicitly clicks **Save profile**.


## Additional updates
- Saving profile information now updates the authenticated user in shared React state and localStorage, so the name/phone/address shown in the sidebar and top-right account header update immediately after Save profile.
- Added a three-dot display menu in the top-right header with 80%, 90%, 100%, 110%, 125%, and 150% zoom options.
- The selected zoom percentage is persisted in localStorage.
- The login panel now uses the technology-devices artwork as a more visible background while retaining a readable form surface.
