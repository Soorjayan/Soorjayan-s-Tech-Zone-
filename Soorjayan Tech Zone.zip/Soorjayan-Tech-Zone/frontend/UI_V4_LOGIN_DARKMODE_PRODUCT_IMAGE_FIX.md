# UI v4 – Login Card, Dark Mode and Product Image Fix

- Login form is now a compact card centered inside the right-side technology artwork panel instead of filling the full half-panel.
- Product images use `object-fit: contain` so the complete image supplied by an image URL is visible without cropping.
- Dark-mode dashboard cards, quick actions, recent orders, stock panels, product cards, text and controls receive stronger dark-theme colors and contrast.
- Dark-mode login uses a compact dark card with the technology-device artwork still visible behind it.
