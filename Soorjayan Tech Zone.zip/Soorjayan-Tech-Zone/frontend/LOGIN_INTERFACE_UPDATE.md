# Tech Zone Login Interface Update

This update changes **only the login interface** and its required styling/assets. Existing application pages, API services, authentication flow, role permissions, and other dashboard interfaces are preserved.

## Updated
- Reference-inspired split-screen login layout.
- Dark navy/blue brand panel and white sign-in panel.
- Uploaded Tech Zone S logo used in the login branding and watermark.
- Email and password fields with icons.
- Password show/hide control.
- Keep-me-signed-in checkbox UI.
- Forgot-password link.
- Gradient Sign In button.
- Create-account action.
- JWT-protected secure-access note.
- Responsive mobile layout.

## Files changed/added
- `src/pages/auth/Login.jsx`
- `src/index.css` (login-specific styles appended)
- `src/assets/tech-zone-s-logo.png`

No backend files were changed.
